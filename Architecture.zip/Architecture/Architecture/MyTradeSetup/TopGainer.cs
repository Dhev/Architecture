﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices; 

namespace MyTradeSetup
{
    public partial class TopGainer : Form
    {
        int interval;
        int displayMin;
        int noOfTopGrainers;
        public MarketTopper curr_MarketTopper;
        public MarketTopper pre_MarketTopper;
        Random r = new Random();
        public TopGainer()
        {
            InitializeComponent();
            intervelTextBox.Text = "5";
            interval = 5;
            displayMin = 0;
            noOfTopGrainersTextBox.Text = "3";
            noOfTopGrainers = 3;
            refreshBtn.Enabled = false;
        }

        private void intervelTextBox_Leave(object sender, EventArgs e)
        {            
            int.TryParse(intervelTextBox.Text, out interval);
            if ((interval<3) || (interval>60))
            {
                MessageBox.Show("Value must be within 3 to 60");
                intervelTextBox.Clear();
                intervelTextBox.Focus();
            }
        }

        private void noOfTopGrainersTextBox_Leave(object sender, EventArgs e)
        {
            int.TryParse(noOfTopGrainersTextBox.Text, out noOfTopGrainers);
            if ((noOfTopGrainers < 2) || (noOfTopGrainers > 10))
            {
                MessageBox.Show("Value must be within 2 to 10");
                noOfTopGrainersTextBox.Clear();
                noOfTopGrainersTextBox.Focus();
            }
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            intervelTimer_Tick(null, null);            
        }

        private void StartProcess()
        {
            if (displayMin == 0)
            {
                DisplayInfo("Loading NSE web site....");
                LoadURL();

                displayMin = (r.Next((interval - 1) * 60, (interval + 1) * 60));
                intervelTimer.Interval = 1000;
                intervelTimer.Enabled = false;
                refreshBtn.Enabled = false;

                DisplayIntervel("");
            }
            else
            {
                DisplayIntervel("NSE site will be refreshed in " + displayMin + " seconds");
                displayMin = displayMin - 1;
            }


            
        }

        private void intervelTimer_Tick(object sender, EventArgs e)
        {
            int HH=Convert.ToInt16(DateTime.Now.ToString("HH"));
            int MM=Convert.ToInt16(DateTime.Now.ToString("mm"));
            TimeSpan now = new TimeSpan(HH, MM, 0); 
            if (workTimeCheckBox.Checked)
            {
                TimeSpan start = new TimeSpan(8, 59, 0);
                TimeSpan end = new TimeSpan(15, 35, 0);
                if ((now > start) && (now < end))
                {
                    StartProcess();
                }
                else
                {
                    DisplayInfo("Process will start at 9 AM...",true);
                    intervelTimer.Enabled = true;
                    displayMin = 0;
                    intervalLbl.Text = "";
                }
            }
            else
            {
                StartProcess();
            }
            TimeSpan startShutdownTime = new TimeSpan(15, 40, 0);
            TimeSpan endShutdownTime = new TimeSpan(15, 45, 0);
            if (shutdownCheckBox.Checked)
            {
                if ((startShutdownTime < now) && (now < endShutdownTime))
                {
                    this.Close();
                    Process.Start("shutdown", "/s /t 0");
                }
            }


        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            displayMin = 3;
        }

        private void DisplayInfo(string info,bool clear=false)
        {
            if (clear) logTextBox.Text="";

            logTextBox.Text += DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") +": " + info + System.Environment.NewLine;
        }

        private void DisplayData(string info)
        {
            dataTextBox.Text += info + System.Environment.NewLine;
        }

        private void DisplayIntervel(string info)
        {
            intervalLbl.Text = info;
        }

        private void LoadURL()
        {
            intervelTimer.Enabled = false;
            refreshBtn.Enabled = false;
            startBtn.Enabled = false;
            workTimeCheckBox.Enabled = false;
            shutdownCheckBox.Enabled = false;
            //webBrowser1.ScriptErrorsSuppressed = true;
            //webBrowser1.Navigate("http://www.moneycontrol.com/stocks/marketstats/nsegainer/index.php");
            try
            {
                webBrowser1.Navigate("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm");
            }
            catch (Exception ex)
            {
                DisplayInfo("Message: " + ex.Message);
                DisplayInfo("Inner Exception: " + ex.InnerException);
            }
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            DisplayInfo("Loading Completed.");            
            //var divCity = webBrowser1.Document.GetElementById("city"); // getting an fist div element
            //var city = divCity.InnerText;
            //label1.Text = "City: " + city;


            //var priceElement = GetElementsByClassName(webBrowser1, "span", "PA2");          
            //label1.Text = "Price: " + priceElement[0].InnerText;

            //var percentageElement = GetElementsByClassName(webBrowser1, "span", "gr_15 uparw_pc");
            //label1.Text += " Percentage: " + percentageElement[0].InnerText;

            //GetTopperFromMoneyControl();

            nseTimer.Start();            
        }

        private void nseTimer_Tick(object sender, EventArgs e)
        {
            nseTimer.Stop();
            GetTopperFromNSE();

            intervelTimer.Enabled = true;
            refreshBtn.Enabled = true;
            startBtn.Enabled = true;
            workTimeCheckBox.Enabled = true;
            shutdownCheckBox.Enabled = true;
        }
        private void GetTopperFromNSE()
        {
            try
            {
                var tableElement = webBrowser1.Document.GetElementById("topGainers");
                var tbodyElement = tableElement.Children[0];

                if (curr_MarketTopper != null) MarketTopper.CopyMarketTopper(curr_MarketTopper, out pre_MarketTopper);

                curr_MarketTopper = new MarketTopper();
                curr_MarketTopper.DateAndTime = DateTime.Now;
                for (int i = 2; i < noOfTopGrainers + 2; i++)
                {

                    var trElement = tbodyElement.Children[i];
                    var stock = trElement.Children[0].InnerText;
                    if (stock == "-")
                    {
                        nseTimer.Start();
                        return;
                    }
                    var price = Convert.ToDecimal(trElement.Children[1].InnerText.Replace(",", ""));
                    var percentage = Convert.ToDecimal(trElement.Children[2].InnerText);

                    curr_MarketTopper.Toppers.Add("Top_" + (i - 1), new Stock(stock, price, 0, 0, percentage)); //SS
                }

                if (pre_MarketTopper == null) MarketTopper.CopyMarketTopper(curr_MarketTopper, out pre_MarketTopper);
                //pre_MarketTopper.Toppers["Top_1"].Name = "Test";
                CompareTopper();
            }
            catch (Exception ex)
            {
                DisplayInfo("Message: " + ex.Message);
                DisplayInfo("Inner Exception: " + ex.InnerException);
            }
        }

        

        private void CompareTopper()
        {
            int count = curr_MarketTopper.Toppers.Count();
            string line = "";
            bool alertEmail = false;
            for (int i = 1; i <= count; i++)
            {
                if (curr_MarketTopper.Toppers["Top_" + i].Name != pre_MarketTopper.Toppers["Top_" + i].Name)
                {
                    alertEmail = true;
                    break;
                }
            }
            line = curr_MarketTopper.DateAndTime + ",";
            for (int i = 1; i <= count; i++)
            {
                line += curr_MarketTopper.Toppers["Top_" + i].Name + "(" + curr_MarketTopper.Toppers["Top_" + i].Percentage + "%),";
            }
            line = line.Substring(0, line.Length - 1);
            DisplayData(line);
            FileHandler f = new FileHandler();
            string filePath = @"c:\Temp\topper" + DateTime.Now.ToString("yyyyMMdd") + ".csv";
            f.FileWrite(filePath, new string[] { line });

            if (alertEmail)
            {
                DisplayInfo("Sending Email");
                this.Refresh();
                
                //string gg= 
                string[] body = dataTextBox.Text.Split(new string[] { System.Environment.NewLine },StringSplitOptions.RemoveEmptyEntries);
                StringBuilder table = new StringBuilder();
                table.Append("<table border='3px'>");
                foreach (string s in body)
                {
                    table.Append("<tr><td>" + s.Replace(",", "</td><td>") + "</td></tr>");
                }
                table.Append("</table>");
                 Mailer m = new Mailer();
                m.SendMail("Top Gainers "+DateTime.Now.ToString("yyyyMMdd"),table.ToString(),new string[] {filePath},true);
                DisplayInfo("Email Sent");
            }
 
        }


        private void GetTopperFromMoneyControl()
        {
            var divElement = GetElementsByClassName(webBrowser1, "div", "bsr_table hist_tbl_hm");
            var tableElement = divElement[0].Children[1];
            var tbodyElement = tableElement.Children[1];
            int top = 5;
            MarketTopper mt = new MarketTopper();
            mt.DateAndTime = DateTime.Now;
            for (int i = 0; i < top; i++)
            {

                var trElement = tbodyElement.Children[i];
                var stock = trElement.Children[0].Children[0].Children[0].InnerText;
                var price = Convert.ToDecimal(trElement.Children[3].InnerText.Replace(",", ""));
                var percentage = Convert.ToDecimal(trElement.Children[6].InnerText);

                mt.Toppers.Add("Top_" + (i + 1), new Stock(stock, price, 0, 0, percentage)); //SS
            }
            pre_MarketTopper = curr_MarketTopper;

            curr_MarketTopper = mt;
            if (pre_MarketTopper == null) pre_MarketTopper = mt;

            CompareTopper();
        }


        private HtmlElement[] GetElementsByClassName(WebBrowser wb, string tagName, string className)
        {
            var l = new List<HtmlElement>();

            var els = webBrowser1.Document.GetElementsByTagName(tagName); // all elems with tag
            foreach (HtmlElement el in els)
            {
                if (el.GetAttribute("className") == className)
                {
                    l.Add(el);
                }
            }

            return l.ToArray();
        }

        private HtmlElement[] GetElementsByClassName(HtmlElement elements, string tagName, string className)
        {
            var l = new List<HtmlElement>();
            var els = elements.GetElementsByTagName(tagName); // all elems with tag
            foreach (HtmlElement el in els)
            {
                if (el.GetAttribute("className") == className)
                {
                    l.Add(el);
                }
            }

            return l.ToArray();
        }

        

       
    }
}
