﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTradeSetup
{
    public partial class StockHistoryUI : Form
    {
        public StockHistoryUI()
        {
            InitializeComponent();
            textBox2.Text = "901";
            textBox3.Text = "1d";
            radioBtn30Mins.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string url = ("https://www.google.com/finance/getprices?q=" + textBox1.Text + "&x=NSE&i=" + textBox2.Text + "&p=" + textBox3.Text + "&f=d,o,h,l,c,v");
            webBrowser1.Navigate(url);
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();

            return dtDateTime;
        }


        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            string data = webBrowser1.Document.GetElementsByTagName("pre")[0].InnerText;
            string[] lines = data.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            double UnixTimeStamp = 0;
            DataTable dataDT = new DataTable();
            dataDT.Columns.Add(new DataColumn("DateTime"));
            dataDT.Columns.Add(new DataColumn("OPEN"));
            dataDT.Columns.Add(new DataColumn("CLOSE"));
            dataDT.Columns.Add(new DataColumn("HIGH"));
            dataDT.Columns.Add(new DataColumn("LOW"));
            dataDT.Columns.Add(new DataColumn("VOLUME"));

            for (int i = 7; i < lines.Length; i++)
            {
                string[] columns = lines[i].Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                DateTime dt;
                DataRow dataDR = dataDT.NewRow();
                if (columns[0].StartsWith("a"))
                {
                    UnixTimeStamp = Convert.ToDouble(columns[0].Replace("a", ""));
                    dt = UnixTimeStampToDateTime(UnixTimeStamp);
                }
                else
                {
                    dt = UnixTimeStampToDateTime(UnixTimeStamp + (Convert.ToDouble(columns[0]) * Convert.ToInt16(textBox2.Text)));
                }
                dataDR["DateTime"] = dt;
                //CLOSE,HIGH,LOW,OPEN,VOLUME
                dataDR["CLOSE"] = columns[1];
                dataDR["HIGH"] = columns[2];
                dataDR["LOW"] = columns[3];
                dataDR["OPEN"] = columns[4];
                dataDR["VOLUME"] = columns[5];
                dataDT.Rows.Add(dataDR);

            }

           // dataDT = RemoveYesterdayRows(dataDT);
          //  dataDT = RemovePreMarketRow(dataDT);

            

            if (intervalRadioBtn.Checked)
                dataGridView1.DataSource = dataDT;
            else
            {
                DataTable stock30mins = Convert30minDT(dataDT);
                dataGridView1.DataSource = stock30mins;
            }

        }


        private DataTable RemoveYesterdayRows(DataTable dataDT)
        {
            List<DataRow> rowsToDelete = new List<DataRow>();
            bool hasOldData = false;
            for (int i = 0; i < dataDT.Rows.Count; i++)
            {
                DateTime dt = Convert.ToDateTime(dataDT.Rows[i]["datetime"]);
                //DateTime dt = DateTime.ParseExact(ss, "dd-MM-yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                if (dt.ToString("dd-MM-yyyy") != DateTime.Now.ToString("dd-MM-yyyy"))
                {
                    rowsToDelete.Add(dataDT.Rows[i]);
                    hasOldData = true;
                }
            }
            //if (hasOldData)
            //    logTextBox.AppendText(DateTime.Now.ToString("d/M/yy hh:mm:ss tt") + ": Stock " + stock + " has old data." + System.Environment.NewLine);

            foreach (DataRow row in rowsToDelete)
            {
                dataDT.Rows.Remove(row);
            }

            return dataDT;
        }

        private DataTable RemovePreMarketRow(DataTable dataDT)
        {
            if (dataDT != null && dataDT.Rows.Count > 0)
            {
                DateTime dt = Convert.ToDateTime(dataDT.Rows[0]["datetime"]);
                //DateTime dt = DateTime.ParseExact(ss, "dd-MM-yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                if ((dt.Hour == 9) && (dt.Minute == 15))
                {
                    dataDT.Rows.RemoveAt(0);
                }
            }
            return dataDT;
        }

        private DataTable Convert30minDT(DataTable data15minsDT)
        {
            DataTable data30min = new DataTable();
            data30min.Columns.Add(new DataColumn("datetime", typeof(DateTime)));
            data30min.Columns.Add(new DataColumn("open", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("close", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("high", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("low", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("volume", typeof(int)));

            if (data15minsDT != null)
            {
                if (data15minsDT.Rows.Count >= 2)
                {
                    int count = data15minsDT.Rows.Count;
                    if ((count % 2) != 0)
                        count = count - 1;

                    for (int i = 0; i < count; i = i + 2)
                    {
                        StockPrice sp1;
                        StockPrice sp2;
                        GetRowData(data15minsDT, i, i + 1, out sp1, out sp2);

                        DataRow dr = data30min.NewRow();
                        dr["datetime"] = data15minsDT.Rows[i + 1]["datetime"];
                        dr["open"] = sp1.Open;
                        dr["close"] = sp2.Close;

                        if (sp1.High > sp2.High)
                            dr["high"] = sp1.High;
                        else
                            dr["high"] = sp2.High;

                        if (sp1.Low < sp2.Low)
                            dr["low"] = sp1.Low;
                        else
                            dr["low"] = sp2.Low;

                        dr["volume"] = Convert.ToInt32(data15minsDT.Rows[i]["volume"]) + Convert.ToInt32(data15minsDT.Rows[i + 1]["volume"]);

                        data30min.Rows.Add(dr);
                    }
                }
            }

            return data30min;
        }


        public void GetRowData(DataTable dataDT, int rowNo1, int rowNo2, out StockPrice sp1, out StockPrice sp2) //move this method to util
        {
            sp1 = new StockPrice();
            sp1.Open = Convert.ToDouble(dataDT.Rows[rowNo1]["open"]);
            sp1.Close = Convert.ToDouble(dataDT.Rows[rowNo1]["close"]);
            sp1.High = Convert.ToDouble(dataDT.Rows[rowNo1]["high"]);
            sp1.Low = Convert.ToDouble(dataDT.Rows[rowNo1]["low"]);

            sp2 = new StockPrice();
            sp2.Open = Convert.ToDouble(dataDT.Rows[rowNo2]["open"]);
            sp2.Close = Convert.ToDouble(dataDT.Rows[rowNo2]["close"]);
            sp2.High = Convert.ToDouble(dataDT.Rows[rowNo2]["high"]);
            sp2.Low = Convert.ToDouble(dataDT.Rows[rowNo2]["low"]);

        }

        public class StockPrice
        {
            public double Open { get; set; }
            public double Close { get; set; }
            public double High { get; set; }
            public double Low { get; set; }
        }


    }
}
