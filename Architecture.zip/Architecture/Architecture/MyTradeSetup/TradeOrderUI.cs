﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;


namespace MyTradeSetup
{
    public partial class TradeOrderUI : Form
    {
        DataTable topGainerOrderDT;
        DataTable priceActionOrderDT;
        DataTable orbDT;

        string mailTableHeader;

        string topGainerMailTableFooter;
        string priceActionMailTableFooter;
        string orbMailTableFooter;

        string topGainerFileHeader;
        string priceActionFileHeader;
        string orbFileHeader;

        StringBuilder mailTableforTopGainer;
        StringBuilder mailTableforPriceAction;
        StringBuilder mailTableforORB;
        Mailer m;

        LiveOrders liveOrders;

        double todayHigh = 0;
        double todayLow = 0;
        
        string logicName,headerText;
        LiveOrders liveOrder;
        public TradeOrderUI(string LogicName, string headerText)
        {
            InitializeComponent();
            this.Text = headerText;
            this.headerText = headerText;
            CreateDataTableColumns();
 
            timer1.Interval = 500;
            timer1.Enabled = true;
            timer1.Start();

            mailTableforTopGainer = new StringBuilder();
            mailTableforPriceAction = new StringBuilder();
            mailTableforORB = new StringBuilder();

            //splitContainer1.Panel1Collapsed = true;
            m = new Mailer();
            liveOrders = new LiveOrders();
            logicName = LogicName;
            liveOrder = new LiveOrders();

        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime startTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 15, 0, 0);
            DateTime endTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0, 0);
            if ((startTime <= DateTime.Now) && (DateTime.Now <= endTime))
                LoadCurrPrice();
        }

        private void FileWrite(string htmlData, string fileName)
        {
            if (String.IsNullOrEmpty(htmlData) == false)
            {
              //  htmlData += "<html><body>Regards,<br/>S.Suresh<br/>Cell: 9789865522<br/>Email: <a href='mailto:ssvelu83@gmail.com'>ssvelu83@gmail.com</a></body></html>";
                FileHandler fh = new FileHandler();
                fh.WriteTodayOrdersInFile(htmlData, fileName,false);
            }
        }


        private void LoadCurrPrice()
        {
            if (Orders.MyOrders == null || Orders.MyOrders.Count == 0) return;

            bool triggerMail = false;
            try
            {
                foreach (Order o in Orders.MyOrders)
                {
                    if (logicName != o.MailGrpByName) continue;

                    if (o.ValidUpTo <= DateTime.Now)
                    {
                        if (o.OrderStatus == OrderStatus.NotExecuted) o.OrderStatus = OrderStatus.TimeElapsed;
                    }
                    double pri = 0;
                    if (OrderSettings.Api == API.GoogleFinance)
                        pri = Communicator.StockPriceFormGoogleFinance.GetPrice(o.Stock);
                    else
                        pri = Communicator.StockPriceFormZerodha.GetPrice(o.Stock);

                    //Testing
                    //if (o.Stock == "BOSCHLTD")
                    //{
                    //    if (1 == 1)
                    //        pri = 22718.5;
                    //    else
                    //        pri = 22618.5;
                    //}

                    if (pri == 0) continue;

                    if (DateTime.Now < DateTime.ParseExact(DateTime.Now.Date.ToString("yyyy-MM-dd") + " 03:06:00 PM", "yyyy-MM-dd hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture))
                    {
                        if (o.OrderStatus == OrderStatus.NotExecuted)
                        {
                            bool isThisisFirstTime = (o.CurrPrice == 0) ;
                            if ((o.OrderType == OrderType.Buy) && (o.BuyPrice == 0))
                            {
                                if (CheckPriceMatched(pri, o))
                                {
                                    bool placeOrder = false;
                                    if (o.TopGinerLosser > 0)
                                    {
                                        int top = Communicator.TopGainerLoser.IsTopGainer(o.Stock);
                                        if ((top > 0) && (top <= o.TopGinerLosser))
                                            placeOrder = true;
                                        else
                                            o.UpdateDetail("Not in Top " + o.TopGinerLosser + " Gainner");
                                    }
                                    else
                                        placeOrder = true;

                                    if (placeOrder)
                                    {
                                        o.TrailingSLPrice = 0;
                                        o.BuyPrice = Convert.ToDouble(pri);
                                        o.OrderStatus = OrderStatus.InProgress;
                                        o.Target = Convert.ToDouble(pri) + calcPercentageForPlaceOrder(pri, o.TargetPercentage);
                                        CalcStopLoss(o);
                                        triggerMail = true;
                                    }
                                }                                
                            }
                            if ((o.OrderType == OrderType.Sell) && (o.SellPrice == 0))
                            {
                                if (CheckPriceMatched(Convert.ToDouble(pri), o))
                                {
                                    bool placeOrder = false;
                                    if (o.TopGinerLosser > 0)
                                    {
                                        int top = Communicator.TopGainerLoser.IsTopLoser(o.Stock);
                                        if ((top > 0) && (top <= o.TopGinerLosser))
                                            placeOrder = true;
                                        else
                                            o.UpdateDetail("Not in Top " + o.TopGinerLosser + " Loser");
                                    }
                                    else
                                        placeOrder = true;
                                    
                                    if (placeOrder)
                                    {
                                        o.TrailingSLPrice = 0;
                                        o.SellPrice = Convert.ToDouble(pri);
                                        o.OrderStatus = OrderStatus.InProgress;
                                        o.Target = Convert.ToDouble(pri) - calcPercentageForPlaceOrder(pri, o.TargetPercentage);
                                        CalcStopLoss(o);
                                        triggerMail = true;
                                    }
                                }
                            }
                            if (isThisisFirstTime)
                                o.OrderId = liveOrder.PlaceOrder(o.Stock, o.OrderType.ToString(), o.Qty, o.TriggerPrice, o.Target, o.StopLoss); 
                        }
                    }


                    o.CurrPrice = pri;
                    OrderStatus oldOS = o.OrderStatus;
                    o.CheckOrderCompleted();
                    if (oldOS != o.OrderStatus)
                        triggerMail = true;

                }

                UpdateDataTable();
                if (triggerMail)
                    sentMail();
                
            }
            catch (Exception exception)
            {
                ErrorHandler.LogError(exception);
            }
            finally
            {
                timer1.Start();
            }
        }

        private void sentMail()
        {
            string mailData = "";
            if (String.IsNullOrEmpty(mailTableforPriceAction.ToString()) == false)
            {
                mailData = "<html><body><h1>Price Action</h1><table  border='1px'>" + mailTableHeader + mailTableforPriceAction + priceActionMailTableFooter + "</table></body></html><br/><br/>";
                m.SendMail("Orders-" + DateTime.Now.ToString("yyyyMMdd") + " " + priceActionFileHeader, mailData, null, true);
            }

            if (String.IsNullOrEmpty(mailTableforTopGainer.ToString()) == false)
            {
                mailData = "<html><body><h1>Top Gainer</h1><table  border='1px'>" + mailTableHeader + mailTableforTopGainer + topGainerMailTableFooter + "</table></body></html>";
                m.SendMail("Orders-" + DateTime.Now.ToString("yyyyMMdd") + " " + Orders.MyOrders[0].MailGrpByName, mailData, null, true);
            }

            if (String.IsNullOrEmpty(mailTableforORB.ToString()) == false)
            {
                mailData = "<html><body><h1>ORB</h1><table  border='1px'>" + mailTableHeader + mailTableforORB + orbMailTableFooter + "</table></body></html>";
                m.SendMail("Orders-" + DateTime.Now.ToString("yyyyMMdd") + " " + orbFileHeader, mailData, null, true);
            }

            string htmlData = "";
            if (String.IsNullOrEmpty(mailTableforPriceAction.ToString()) == false)
            {
                if (Orders.MyOrders.Count > 0)
                    htmlData = @"<html><body><h3>" + priceActionFileHeader + @"</h3></body></html><br/>";

                htmlData += "<html><body><h3>Price Action</h3><table  border='1px'>" + mailTableHeader + mailTableforPriceAction + priceActionMailTableFooter + "</table></body></html><br/><br/>";
                FileWrite(htmlData, headerText);
            }

            if (String.IsNullOrEmpty(mailTableforORB.ToString()) == false)
            {
                if (Orders.MyOrders.Count > 0)
                    htmlData = @"<html><body><h3>" + orbFileHeader + @"</h3></body></html><br/>";

                htmlData += "<html><body><h3>Price Action</h3><table  border='1px'>" + mailTableHeader + mailTableforORB + orbMailTableFooter + "</table></body></html><br/><br/>";
                FileWrite(htmlData, headerText);
            }

            if (String.IsNullOrEmpty(mailTableforTopGainer.ToString()) == false)
            {
                if (Orders.MyOrders.Count > 0)
                    htmlData = @"<html><body><h3>" + topGainerFileHeader + @"</h3></body></html><br/>";

                htmlData += "<html><body><h3>Top Gainer</h3><table  border='1px'>" + mailTableHeader + mailTableforTopGainer + topGainerMailTableFooter + "</table></body></html>";

                FileWrite(htmlData, headerText);
            }
        }

        private void CalcStopLoss(Order o)
        {
            if (o.StopLossPercentage != 0)
            {
                if (o.OrderType == OrderType.Buy)
                {
                    double slPoints = calcPercentageForPlaceOrder(o.BuyPrice, o.StopLossPercentage);
                    double sl = o.BuyPrice - slPoints;
                    if (sl > o.StopLoss)
                        o.StopLoss = sl;
                }
                else
                {
                    double slPoints = calcPercentageForPlaceOrder(o.SellPrice, o.StopLossPercentage);
                    double sl = o.SellPrice + slPoints;
                    if (sl < o.StopLoss)
                        o.StopLoss = sl;
                }
            }
        }

        private bool CheckPriceMatched(double currPrice, Order o)
        {
            double triggerPercentage = 0.2;
            this.Text = headerText + ". Trigger Price will be (+/-)" + triggerPercentage.ToString() + "% for Buy/Sell Orders";
            double startPrice = 0;
            double endPrice = 0;
            double triggerPrice = o.TriggerPrice;
            bool result = false;
            if (o.OrderType == OrderType.Buy)
            {
                if (o.CurrPrice == 0)
                {
                    startPrice = triggerPrice + calcPercentageForPlaceOrder(triggerPrice, triggerPercentage);
                    endPrice = triggerPrice + calcPercentageForPlaceOrder(triggerPrice, (triggerPercentage * 2));
                }
                else
                {
                    startPrice = triggerPrice;
                    endPrice = triggerPrice + calcPercentageForPlaceOrder(triggerPrice, triggerPercentage);
                }

                //100<=101  101<=103
                if ((startPrice <= currPrice) && (currPrice <= endPrice))
                    result = true;
            }
            else
            {

                if (o.CurrPrice == 0)
                {
                    startPrice = triggerPrice - calcPercentageForPlaceOrder(triggerPrice, triggerPercentage);
                    endPrice = triggerPrice - calcPercentageForPlaceOrder(triggerPrice, (triggerPercentage * 2));
                }
                else
                {
                    startPrice = triggerPrice;
                    endPrice = triggerPrice - calcPercentageForPlaceOrder(triggerPrice, triggerPercentage);
                }
                // 100>=99  99>=98
                if ((startPrice >= currPrice) && (currPrice >= endPrice))
                    result = true;
            }
            if (o.CurrPrice == 0) //if this is first time
            {
                o.TriggerPrice = startPrice;
                o.Qty = Calc.GetQty(o.TriggerPrice);

                bool isSLPercentage_temp = false;
                double sl_temp = 0;
                if (o.StopLossPercentage>0)
                {
                    isSLPercentage_temp = true;
                    sl_temp = o.StopLossPercentage;
                }
                else
                {
                    isSLPercentage_temp = false;
                    sl_temp = o.StopLoss;
                }

            }
            return result;
        }

        private double calcPercentageForPlaceOrder(double price, double percentage)
        {
            double calVal = (percentage / 100) * price;
            return Math.Round(calVal, 2);
        }
 
        private void CreateDataTableColumns()
        {
            topGainerOrderDT = new DataTable();
            //topGainnerOrderDT.Columns.Add("Strategy");
            topGainerOrderDT.Columns.Add("Stock");
            topGainerOrderDT.Columns.Add("DateTime");
            topGainerOrderDT.Columns.Add("OrderType");
            topGainerOrderDT.Columns.Add("BuyPrice");
            topGainerOrderDT.Columns.Add("SellPrice");
            topGainerOrderDT.Columns.Add("Qty");
            topGainerOrderDT.Columns.Add("CurrPrice");
            topGainerOrderDT.Columns.Add("ProfitLoss");
            topGainerOrderDT.Columns.Add("PLPercentage");
            topGainerOrderDT.Columns.Add("Trigger");
            topGainerOrderDT.Columns.Add("Target");
            topGainerOrderDT.Columns.Add("StopLoss");
            topGainerOrderDT.Columns.Add("OrderStatus");
            topGainerOrderDT.Columns.Add("Detail");
 
            priceActionOrderDT = new DataTable();
            //priceActionOrderDT.Columns.Add("Strategy");
            priceActionOrderDT.Columns.Add("Stock");
            priceActionOrderDT.Columns.Add("DateTime");
            priceActionOrderDT.Columns.Add("OrderType");
            priceActionOrderDT.Columns.Add("BuyPrice");
            priceActionOrderDT.Columns.Add("SellPrice");
            priceActionOrderDT.Columns.Add("Qty");
            priceActionOrderDT.Columns.Add("CurrPrice");
            priceActionOrderDT.Columns.Add("ProfitLoss");
            priceActionOrderDT.Columns.Add("PLPercentage");
            priceActionOrderDT.Columns.Add("Trigger");
            priceActionOrderDT.Columns.Add("Target");
            priceActionOrderDT.Columns.Add("StopLoss");
            priceActionOrderDT.Columns.Add("OrderStatus");
            priceActionOrderDT.Columns.Add("Detail");

            orbDT = new DataTable();
            //priceActionOrderDT.Columns.Add("Strategy");
            orbDT.Columns.Add("Stock");
            orbDT.Columns.Add("DateTime");
            orbDT.Columns.Add("OrderType");
            orbDT.Columns.Add("BuyPrice");
            orbDT.Columns.Add("SellPrice");
            orbDT.Columns.Add("Qty");
            orbDT.Columns.Add("CurrPrice");
            orbDT.Columns.Add("ProfitLoss");
            orbDT.Columns.Add("PLPercentage");
            orbDT.Columns.Add("Trigger");
            orbDT.Columns.Add("Target");
            orbDT.Columns.Add("StopLoss");
            orbDT.Columns.Add("OrderStatus");
            orbDT.Columns.Add("Detail");

            mailTableHeader = @"<tr style='background-color:#0a0a32;color:#FFFFFF'>
                                <th>#</th>
                                <th>Stock</th>
                                <th>DateTime</th>  
                                <th>OrdType</th>
                                <th>BuyPrice</th>
                                <th>SellPrice</th>
                                <th>Qty</th>
                                <th>CurrPrice</th>
                                <th>ProfitLoss</th>
                                <th>PL%</th>
                                <th>Trigger</th>
                                <th>Target</th>
                                <th>StopLoss</th>
                                <th>OrderStatus</th>
                                <th>Detail</th>
                                </tr>";
        }
 
        private void UpdateDataTable()
        {
            topGainerOrderDT.Rows.Clear();
            priceActionOrderDT.Rows.Clear();
            orbDT.Rows.Clear();

            mailTableforTopGainer.Clear();
            mailTableforPriceAction.Clear();
            mailTableforORB.Clear();

            string topGainnerRowColor = "#dae5f4";
            string priceActionRowColor = "#dae5f4";
            string orbRowColor = "#dae5f4";

            int topGainnerCount = 1;
            int priceActionCount = 1;
            int orbCount = 1;

            double topGannerTotal = 0;
            double priceActionTotal = 0;
            double orbTotal = 0;

            double topGannerTotalPercent = 0;
            double priceActionTotalPercent = 0;
            double orbTotalPercent = 0;

            int profitTradeCount = 0;
            int lossTradeCount = 0;
            double currProfit = 0;

            footerTxtBox.Text = "";
            foreach (Order o in Orders.MyOrders)
            {
                if (logicName != o.MailGrpByName) continue;

                currProfit = currProfit + o.ProfitLoss;
                if (o.ProfitLoss > 0)
                    profitTradeCount = profitTradeCount + 1;
                if (o.ProfitLoss < 0)
                    lossTradeCount = lossTradeCount + 1;

                footerTxtBox.Text = "Current Profit: " + currProfit.ToString() + ", ";
                footerTxtBox.Text += "Profit Count: " + profitTradeCount.ToString() + ", ";
                footerTxtBox.Text += "Loss Count: " + lossTradeCount.ToString() + ", ";

                #region Top Gainer
                if (o.Strategy == Strategy.TopGainner)
                {
                    DataRow dr = topGainerOrderDT.NewRow();
                    //dr["Strategy"] = o.Strategy;
                    dr["Stock"] = o.Stock;
                    dr["DateTime"] = o.DateTime;
                    dr["OrderType"] = o.OrderType;
                    dr["BuyPrice"] = o.BuyPrice;
                    dr["SellPrice"] = o.SellPrice;
                    dr["Qty"] = o.Qty;
                    dr["CurrPrice"] = o.CurrPrice;
                    dr["ProfitLoss"] = o.ProfitLoss;
                    dr["PLPercentage"] = o.PLPercentage;
                    dr["Trigger"] = o.TriggerPrice;
                    dr["Target"] = o.Target;
                    dr["StopLoss"] = o.StopLoss;
                    dr["OrderStatus"] = o.OrderStatus;
                    dr["Detail"] = o.Detail;
                    topGainerOrderDT.Rows.Add(dr);

                    if (topGainnerRowColor == "#dae5f4") topGainnerRowColor = "#b8d1f3";
                    else topGainnerRowColor = "#dae5f4";

                    string plFontColor = "";
                    if (o.ProfitLoss < 0)
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Red";
                        else
                            plFontColor = "Orange";
                    }
                    else if (o.ProfitLoss == 0)
                        plFontColor = topGainnerRowColor;
                    else
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Green";
                        else
                            plFontColor = "#09ef09";
                    }


                    mailTableforTopGainer.Append("<tr style='background-color:" + topGainnerRowColor + "'>"); //<td>" + o.Strategy + "</td>");
                    mailTableforTopGainer.Append("<td>" + topGainnerCount.ToString() + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.Stock + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.DateTime.ToString("hh:mm tt") + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.OrderType + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.BuyPrice + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.SellPrice + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.Qty + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.CurrPrice + "</td>");
                    mailTableforTopGainer.Append("<td><span style='background-color:" + plFontColor + "'>" + o.ProfitLoss + "</span></td>");
                    mailTableforTopGainer.Append("<td>" + o.PLPercentage + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.TriggerPrice + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.Target + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.StopLoss + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.OrderStatus + "</td>");
                    mailTableforTopGainer.Append("<td>" + o.Detail.Replace(Environment.NewLine, " <br>") + "</td>");
                    mailTableforTopGainer.Append("</tr >");
                    topGainnerCount = topGainnerCount + 1;
                    topGannerTotal = topGannerTotal + o.ProfitLoss;
                    topGannerTotalPercent = topGannerTotalPercent + o.PLPercentage;
                }
                #endregion

                #region Price Action
                if (o.Strategy == Strategy.PriceAction)
                {
                    DataRow dr = priceActionOrderDT.NewRow();
                    //dr["Strategy"] = o.Strategy;
                    dr["Stock"] = o.Stock;
                    dr["DateTime"] = o.DateTime;
                    dr["OrderType"] = o.OrderType;
                    dr["BuyPrice"] = o.BuyPrice;
                    dr["SellPrice"] = o.SellPrice;
                    dr["Qty"] = o.Qty;
                    dr["CurrPrice"] = o.CurrPrice;
                    dr["ProfitLoss"] = o.ProfitLoss;
                    dr["PLPercentage"] = o.PLPercentage;
                    dr["Trigger"] = o.TriggerPrice;
                    dr["Target"] = o.Target;
                    dr["StopLoss"] = o.StopLoss;
                    dr["OrderStatus"] = o.OrderStatus;
                    dr["Detail"] = o.Detail;
                    priceActionOrderDT.Rows.Add(dr);

                    priceActionFileHeader = o.MailGrpByName;
                    orderGridHeaderTxt.Text = o.MailGrpByName;

                    if (priceActionRowColor == "#dae5f4") priceActionRowColor = "#b8d1f3";
                    else priceActionRowColor = "#dae5f4";

                    string plFontColor = "";
                    if (o.ProfitLoss < 0)
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Red";
                        else
                            plFontColor = "Orange";
                    }
                    else if (o.ProfitLoss == 0)
                        plFontColor = priceActionRowColor;
                    else
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Green";
                        else
                            plFontColor = "#09ef09";
                    }

                    mailTableforPriceAction.Append("<tr style='background-color:" + priceActionRowColor + "'>"); //<td>" + o.Strategy + "</td>");
                    mailTableforPriceAction.Append("<td>" + priceActionCount.ToString() + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.Stock + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.DateTime.ToString("hh:mm tt") + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.OrderType + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.BuyPrice + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.SellPrice + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.Qty + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.CurrPrice + "</td>");
                    mailTableforPriceAction.Append("<td><span style='background-color:" + plFontColor + "'>" + o.ProfitLoss + "</span></td>");
                    mailTableforPriceAction.Append("<td>" + o.PLPercentage + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.TriggerPrice + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.Target + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.StopLoss + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.OrderStatus + "</td>");
                    mailTableforPriceAction.Append("<td>" + o.Detail.Replace(Environment.NewLine, "<br>") + "</td>");
                    mailTableforPriceAction.Append("</tr>");
                    priceActionCount = priceActionCount + 1;
                    priceActionTotal = priceActionTotal + o.ProfitLoss;
                    priceActionTotalPercent = priceActionTotalPercent + o.PLPercentage;
                }
                #endregion

                #region ORB
                if (o.Strategy == Strategy.ORB)
                {
                    DataRow dr = orbDT.NewRow();
                    //dr["Strategy"] = o.Strategy;
                    dr["Stock"] = o.Stock;
                    dr["DateTime"] = o.DateTime;
                    dr["OrderType"] = o.OrderType;
                    dr["BuyPrice"] = o.BuyPrice;
                    dr["SellPrice"] = o.SellPrice;
                    dr["Qty"] = o.Qty;
                    dr["CurrPrice"] = o.CurrPrice;
                    dr["ProfitLoss"] = o.ProfitLoss;
                    dr["PLPercentage"] = o.PLPercentage;
                    dr["Trigger"] = o.TriggerPrice;
                    dr["Target"] = o.Target;
                    dr["StopLoss"] = o.StopLoss;
                    dr["OrderStatus"] = o.OrderStatus;
                    dr["Detail"] = o.Detail;
                    orbDT.Rows.Add(dr);

                    orbFileHeader = o.MailGrpByName;
                    orderGridHeaderTxt.Text = o.MailGrpByName;

                    if (orbRowColor == "#dae5f4") orbRowColor = "#b8d1f3";
                    else orbRowColor = "#dae5f4";

                    string plFontColor = "";
                    if (o.ProfitLoss < 0)
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Red";
                        else
                            plFontColor = "Orange";
                    }
                    else if (o.ProfitLoss == 0)
                        plFontColor = orbRowColor;
                    else
                    {
                        if (o.OrderStatus == OrderStatus.Completed)
                            plFontColor = "Green";
                        else
                            plFontColor = "#09ef09";
                    }

                    mailTableforORB.Append("<tr style='background-color:" + orbRowColor + "'>"); //<td>" + o.Strategy + "</td>");
                    mailTableforORB.Append("<td>" + orbCount.ToString() + "</td>");
                    mailTableforORB.Append("<td>" + o.Stock + "</td>");
                    mailTableforORB.Append("<td>" + o.DateTime.ToString("hh:mm tt") + "</td>");
                    mailTableforORB.Append("<td>" + o.OrderType + "</td>");
                    mailTableforORB.Append("<td>" + o.BuyPrice + "</td>");
                    mailTableforORB.Append("<td>" + o.SellPrice + "</td>");
                    mailTableforORB.Append("<td>" + o.Qty + "</td>");
                    mailTableforORB.Append("<td>" + o.CurrPrice + "</td>");
                    mailTableforORB.Append("<td><span style='background-color:" + plFontColor + "'>" + o.ProfitLoss + "</span></td>");
                    mailTableforORB.Append("<td>" + o.PLPercentage + "</td>");
                    mailTableforORB.Append("<td>" + o.TriggerPrice + "</td>");
                    mailTableforORB.Append("<td>" + o.Target + "</td>");
                    mailTableforORB.Append("<td>" + o.StopLoss + "</td>");
                    mailTableforORB.Append("<td>" + o.OrderStatus + "</td>");
                    mailTableforORB.Append("<td>" + o.Detail.Replace(Environment.NewLine, "<br>") + "</td>");
                    mailTableforORB.Append("</tr>");
                    orbCount = orbCount + 1;
                    orbTotal = orbTotal + o.ProfitLoss;
                    orbTotalPercent = orbTotalPercent + o.PLPercentage;
                }
                #endregion
            }
            topGainerMailTableFooter = @"<tr style='background-color:#0a0a32;color:#FFFFFF'>
                                <th></th>
                                <th></th>
                                <th></th>  
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>" + topGannerTotal + @"</th>
                                <th>" + topGannerTotalPercent + @"</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                </tr>";
            priceActionMailTableFooter = @"<tr style='background-color:#0a0a32;color:#FFFFFF'>
                                <th></th>
                                <th></th>
                                <th></th>  
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>" + priceActionTotal + @"</th>
                                <th>" + priceActionTotalPercent + @"</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                </tr>";
            orbMailTableFooter = @"<tr style='background-color:#0a0a32;color:#FFFFFF'>
                                <th></th>
                                <th></th>
                                <th></th>  
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th>" + orbTotal + @"</th>
                                <th>" + orbTotalPercent + @"</th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                <th></th>
                                </tr>";

            if (logicName.StartsWith("Price Action"))
            {
                orderDataGridView.DataSource = priceActionOrderDT;
                if (footerTxtBox.Text != "")
                {
                    if (todayHigh < priceActionTotal)
                        todayHigh = priceActionTotal;

                    if (todayLow > priceActionTotal)
                        todayLow = priceActionTotal;

                    footerTxtBox.Text += "Today High: " + todayHigh.ToString() + ", ";
                    footerTxtBox.Text += "Today Low: " + todayLow.ToString() + ", ";
                }
            }
            else
                orderDataGridView.DataSource = orbDT;
        }
    }
}
