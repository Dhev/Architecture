﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTradeSetup
{
    public class Calc
    {
        public static double CalcPercentage(double price,double percentage)
        {
            return Math.Round((percentage / 100) * price, 2);
        }

        public static int GetQty(double price)
        {
            return (int)Math.Round(AppConfig.InvestmentAmt / price, 0);
        }
    }
}
