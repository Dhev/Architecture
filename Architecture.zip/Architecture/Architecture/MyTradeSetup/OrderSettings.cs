﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTradeSetup
{
    public partial class OrderSettings : Form
    {
        public static bool CloseAllOrders = false;
        public static bool LiveOrder = false;
        public static API Api = API.GoogleFinance;
        double todayHigh;
        double todayLow;
        int profitTradeCount;
        int lossTradeCount;
        bool mailSent;
        Mailer m;
        public OrderSettings()
        {
            InitializeComponent();
            profitTxtBox.Text = "0";
            profitTxtBox.Focus();
            timer1.Start();
            m = new Mailer();
        }

        private void profitTxtBox_Leave(object sender, EventArgs e)
        {
            double temp;
            if (double.TryParse(profitTxtBox.Text, out temp) == false)
            {
                MessageBox.Show("Enter a valid profit amout");
                profitTxtBox.Focus();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LiveOrder = liveOrderCheckBox.Checked;
            if (googleRadioBtn.Checked)
                Api = API.GoogleFinance;
            else
                Api = API.Zerodha;

            double totProfit = 0;
            profitTradeCount = 0;
            lossTradeCount = 0;
            if (Orders.MyOrders != null)
            {
                foreach (Order o in Orders.MyOrders)
                {
                    totProfit = totProfit + o.ProfitLoss;
                    if (o.ProfitLoss > 0)
                        profitTradeCount = profitTradeCount + 1;
                    if (o.ProfitLoss < 0)
                        lossTradeCount = lossTradeCount + 1;
                }
            }
            if (todayHigh < totProfit)
                todayHigh = totProfit;

            if (todayLow > totProfit)
                todayLow = totProfit;

            statusLbl.Text = "Today High: " + todayHigh.ToString() + System.Environment.NewLine;
            statusLbl.Text += "Today Low: " + todayLow.ToString() + System.Environment.NewLine;
            statusLbl.Text += "Current Profit: " + totProfit.ToString() + System.Environment.NewLine;
            statusLbl.Text += "Profit Order Count: " + profitTradeCount.ToString() + System.Environment.NewLine;
            statusLbl.Text += "Loss Order Count: " + lossTradeCount.ToString() + System.Environment.NewLine;

            if (Convert.ToDouble(profitTxtBox.Text) > 0)
            {
                if (totProfit >= Convert.ToDouble(profitTxtBox.Text))
                    CloseAllOrders = true;
            }

            DateTime startTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 30, 0, 0);
            if ((DateTime.Now > startTime && mailSent == false))
            {
                mailSent = true;
                string mailData = "<html><body><h1>Today Profit</h1><h3>" + statusLbl.Text.Replace(System.Environment.NewLine, "<br/>") + "</h3></body></html><br/><br/>";
                m.SendMail("Today High/Low", mailData, null, true);
            }
        }
    }
}
