﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MyTradeSetup
{
    public class LiveOrders
    {
        public string PlaceOrder(string stock, string ordertype, int qty, double price, double target, double stoploss)
        {
            if (OrderSettings.LiveOrder)
                return Communicator.ZerodhaOrder.PlaceOrder(stock, ordertype, qty, price, target, stoploss);
            else
                return "";
        }

        public void ModifyOrder(string parentid, int qty, double target, double stoploss)
        {
            if (OrderSettings.LiveOrder)
                Communicator.ZerodhaOrder.ModifyOrder(parentid, qty, target, stoploss);
        }

        public void ExistOrder(string parentid)
        {
            if (OrderSettings.LiveOrder)
                Communicator.ZerodhaOrder.ExistOrder(parentid);
        }
    }
}
