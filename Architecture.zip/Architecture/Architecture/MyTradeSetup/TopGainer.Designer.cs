﻿namespace MyTradeSetup
{
    partial class TopGainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.shutdownCheckBox = new System.Windows.Forms.CheckBox();
            this.workTimeCheckBox = new System.Windows.Forms.CheckBox();
            this.refreshBtn = new System.Windows.Forms.Button();
            this.intervalLbl = new System.Windows.Forms.Label();
            this.noOfTopGrainersTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startBtn = new System.Windows.Forms.Button();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.intervelTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.logTextBox = new System.Windows.Forms.TextBox();
            this.intervelTimer = new System.Windows.Forms.Timer(this.components);
            this.nseTimer = new System.Windows.Forms.Timer(this.components);
            this.dataTextBox = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.shutdownCheckBox);
            this.panel1.Controls.Add(this.workTimeCheckBox);
            this.panel1.Controls.Add(this.refreshBtn);
            this.panel1.Controls.Add(this.intervalLbl);
            this.panel1.Controls.Add(this.noOfTopGrainersTextBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.startBtn);
            this.panel1.Controls.Add(this.webBrowser1);
            this.panel1.Controls.Add(this.intervelTextBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1060, 97);
            this.panel1.TabIndex = 0;
            // 
            // shutdownCheckBox
            // 
            this.shutdownCheckBox.AutoSize = true;
            this.shutdownCheckBox.Location = new System.Drawing.Point(157, 77);
            this.shutdownCheckBox.Name = "shutdownCheckBox";
            this.shutdownCheckBox.Size = new System.Drawing.Size(129, 17);
            this.shutdownCheckBox.TabIndex = 11;
            this.shutdownCheckBox.Text = "Shutdown at 3:40 PM";
            this.shutdownCheckBox.UseVisualStyleBackColor = true;
            // 
            // workTimeCheckBox
            // 
            this.workTimeCheckBox.AutoSize = true;
            this.workTimeCheckBox.Location = new System.Drawing.Point(12, 77);
            this.workTimeCheckBox.Name = "workTimeCheckBox";
            this.workTimeCheckBox.Size = new System.Drawing.Size(140, 17);
            this.workTimeCheckBox.TabIndex = 10;
            this.workTimeCheckBox.Text = "Works 9 AM to 3:30 PM";
            this.workTimeCheckBox.UseVisualStyleBackColor = true;
            // 
            // refreshBtn
            // 
            this.refreshBtn.Location = new System.Drawing.Point(266, 43);
            this.refreshBtn.Name = "refreshBtn";
            this.refreshBtn.Size = new System.Drawing.Size(56, 23);
            this.refreshBtn.TabIndex = 8;
            this.refreshBtn.Text = "Refresh";
            this.refreshBtn.UseVisualStyleBackColor = true;
            this.refreshBtn.Click += new System.EventHandler(this.refreshBtn_Click);
            // 
            // intervalLbl
            // 
            this.intervalLbl.AutoSize = true;
            this.intervalLbl.Location = new System.Drawing.Point(306, 77);
            this.intervalLbl.Name = "intervalLbl";
            this.intervalLbl.Size = new System.Drawing.Size(16, 13);
            this.intervalLbl.TabIndex = 7;
            this.intervalLbl.Text = "...";
            // 
            // noOfTopGrainersTextBox
            // 
            this.noOfTopGrainersTextBox.Location = new System.Drawing.Point(157, 45);
            this.noOfTopGrainersTextBox.Name = "noOfTopGrainersTextBox";
            this.noOfTopGrainersTextBox.Size = new System.Drawing.Size(47, 20);
            this.noOfTopGrainersTextBox.TabIndex = 6;
            this.noOfTopGrainersTextBox.Leave += new System.EventHandler(this.noOfTopGrainersTextBox_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "No of Top Gainers : ";
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(210, 43);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(50, 23);
            this.startBtn.TabIndex = 3;
            this.startBtn.Text = "Start";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(998, 3);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(50, 45);
            this.webBrowser1.TabIndex = 2;
            this.webBrowser1.Visible = false;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // intervelTextBox
            // 
            this.intervelTextBox.Location = new System.Drawing.Point(157, 19);
            this.intervelTextBox.Name = "intervelTextBox";
            this.intervelTextBox.Size = new System.Drawing.Size(47, 20);
            this.intervelTextBox.TabIndex = 1;
            this.intervelTextBox.Leave += new System.EventHandler(this.intervelTextBox_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Time Intervel (Minutes) : ";
            // 
            // logTextBox
            // 
            this.logTextBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.logTextBox.Location = new System.Drawing.Point(0, 97);
            this.logTextBox.Multiline = true;
            this.logTextBox.Name = "logTextBox";
            this.logTextBox.Size = new System.Drawing.Size(299, 338);
            this.logTextBox.TabIndex = 1;
            // 
            // intervelTimer
            // 
            this.intervelTimer.Interval = 1000;
            this.intervelTimer.Tick += new System.EventHandler(this.intervelTimer_Tick);
            // 
            // nseTimer
            // 
            this.nseTimer.Interval = 1000;
            this.nseTimer.Tick += new System.EventHandler(this.nseTimer_Tick);
            // 
            // dataTextBox
            // 
            this.dataTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataTextBox.Location = new System.Drawing.Point(299, 97);
            this.dataTextBox.Multiline = true;
            this.dataTextBox.Name = "dataTextBox";
            this.dataTextBox.Size = new System.Drawing.Size(761, 338);
            this.dataTextBox.TabIndex = 2;
            // 
            // TopGainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 435);
            this.Controls.Add(this.dataTextBox);
            this.Controls.Add(this.logTextBox);
            this.Controls.Add(this.panel1);
            this.Name = "TopGainer";
            this.Text = "Top Gainer";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox intervelTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox logTextBox;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Timer intervelTimer;
        private System.Windows.Forms.Timer nseTimer;
        private System.Windows.Forms.TextBox noOfTopGrainersTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label intervalLbl;
        private System.Windows.Forms.TextBox dataTextBox;
        private System.Windows.Forms.Button refreshBtn;
        private System.Windows.Forms.CheckBox shutdownCheckBox;
        private System.Windows.Forms.CheckBox workTimeCheckBox;
    }
}