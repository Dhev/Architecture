﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace MyTradeSetup
{
    public partial class ORB : Form
    {
        int interval;
        int displayMin;
        int noOfTopGrainers;
        Random r = new Random();

        bool ProcessLosers = false;

        double targetPercent;
        bool trailingTrarget;
        double stopLossPercent;
        bool trailingStopLoss;

        public ORB()
        {
            InitializeComponent();
            displayMin = 0;

            interval = 5;
            intervelTextBox.Text = interval.ToString();
            
            
            noOfTopGrainers = 5;
            noOfTopGrainersTextBox.Text = noOfTopGrainers.ToString();
            
            refreshBtn.Enabled = false;

            if (Orders.MyOrders == null) Orders.MyOrders = new List<Order>();

            loserTextBox.Text = "Top Gainers" + System.Environment.NewLine;
            gainerTextBox.Text = "Top Losers" + System.Environment.NewLine;

            targetPercent = 0.3;
            trailingTrarget = false;
            stopLossPercent = 0.5;
            trailingStopLoss = false;
        }

        private void intervelTextBox_Leave(object sender, EventArgs e)
        {
            int.TryParse(intervelTextBox.Text, out interval);
            if ((interval < 3) || (interval > 60))
            {
                MessageBox.Show("Value must be within 3 to 60");
                intervelTextBox.Clear();
                intervelTextBox.Focus();
            }
        }

        private void noOfTopGrainersTextBox_Leave(object sender, EventArgs e)
        {
            int.TryParse(noOfTopGrainersTextBox.Text, out noOfTopGrainers);
            if ((noOfTopGrainers < 2) || (noOfTopGrainers > 10))
            {
                MessageBox.Show("Value must be within 2 to 10");
                noOfTopGrainersTextBox.Clear();
                noOfTopGrainersTextBox.Focus();
            }
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            intervelTimer_Tick(null, null);
        }       

        private void intervelTimer_Tick(object sender, EventArgs e)
        {
            if (ProcessLosers)
            {
                StartProcess();
                return;
            }
            int HH = Convert.ToInt16(DateTime.Now.ToString("HH"));
            int MM = Convert.ToInt16(DateTime.Now.ToString("mm"));
            TimeSpan now = new TimeSpan(HH, MM, 0);
            if (workTimeCheckBox.Checked)
            {
                TimeSpan start = new TimeSpan(10, 30, 0);
                TimeSpan end = new TimeSpan(15, 00, 0);
                if ((now > start) && (now < end))
                {
                    StartProcess();
                }
                else
                {
                    DisplayInfo("Process will start at 10:30 AM...", true);
                    intervelTimer.Enabled = true;
                    displayMin = 0;
                    intervalLbl.Text = "";
                }
            }
            else
            {
                StartProcess();
            }
            TimeSpan startShutdownTime = new TimeSpan(15, 40, 0);
            TimeSpan endShutdownTime = new TimeSpan(15, 45, 0);
            if (shutdownCheckBox.Checked)
            {
                if ((startShutdownTime < now) && (now < endShutdownTime))
                {
                    this.Close();
                    Process.Start("shutdown", "/s /t 0");
                }
            }


        }

        private void StartProcess()
        {
            if (ProcessLosers)
            {
                LoadURL();
                intervelTimer.Enabled = false;
                refreshBtn.Enabled = false;
                return;
            }
            if (displayMin == 0)
            {                
                LoadURL();

                displayMin = (r.Next((interval - 1) * 60, (interval + 1) * 60));
                intervelTimer.Enabled = false;
                refreshBtn.Enabled = false;

                DisplayIntervel("");
            }
            else
            {
                DisplayIntervel("NSE site will be refreshed in " + displayMin + " seconds");
                displayMin = displayMin - 1;
            }



        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            displayMin = 3;
        }

        private void DisplayInfo(string info, bool clear = false)
        {
            if (clear) logTextBox.Text = "";

            logTextBox.Text += DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + ": " + info + System.Environment.NewLine;
        }

        private void DisplayData(string info)
        {
            loserTextBox.Text += info + System.Environment.NewLine;
        }

        private void DisplayIntervel(string info)
        {
            intervalLbl.Text = info;
        }

        private void LoadURL()
        {
            intervelTimer.Enabled = false;
            refreshBtn.Enabled = false;
            startBtn.Enabled = false;
            workTimeCheckBox.Enabled = false;
            shutdownCheckBox.Enabled = false;
            //webBrowser1.ScriptErrorsSuppressed = true;
            //webBrowser1.Navigate("http://www.moneycontrol.com/stocks/marketstats/nsegainer/index.php");
            try
            {
                if (ProcessLosers == false)
                {
                    DisplayInfo("Loading Top Gainers....");
                    webBrowser1.Navigate("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm");
                    ProcessLosers = true;
                }
                else
                {
                    DisplayInfo("Loading Top Losers....");
                    webBrowser1.Navigate("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm");
                    ProcessLosers = false;
                }
            }
            catch (Exception ex)
            {
                DisplayInfo("Message: " + ex.Message);
                DisplayInfo("Inner Exception: " + ex.InnerException);
            }
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            
            //var divCity = webBrowser1.Document.GetElementById("city"); // getting an fist div element
            //var city = divCity.InnerText;
            //label1.Text = "City: " + city;


            //var priceElement = GetElementsByClassName(webBrowser1, "span", "PA2");          
            //label1.Text = "Price: " + priceElement[0].InnerText;

            //var percentageElement = GetElementsByClassName(webBrowser1, "span", "gr_15 uparw_pc");
            //label1.Text += " Percentage: " + percentageElement[0].InnerText;

            //GetTopperFromMoneyControl();

            nseTimer.Start();
        }

        private void nseTimer_Tick(object sender, EventArgs e)
        {
            nseTimer.Stop();
            GetTopperFromNSE();
        }
        private void GetTopperFromNSE()
        {
            
            try
            {
                HtmlElement tableElement;
                if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                {
                    tableElement = webBrowser1.Document.GetElementById("topLosers");                    
                }
                else
                {
                    tableElement = webBrowser1.Document.GetElementById("topGainers");
                }
                var tbodyElement = tableElement.Children[0];
                string stocks = "";
                for (int i = 2; i < noOfTopGrainers + 2; i++)
                {

                    var trElement = tbodyElement.Children[i];
                    string stock = trElement.Children[0].InnerText.ToUpper().Trim();
                    stocks += stock + "\t";
                    if (stock == "-")
                    {
                        if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                        {
                            webBrowser1.Document.GetElementById("tab8").InvokeMember("click");
                        }
                        nseTimer.Start();
                        return;
                    }
                    double price = Convert.ToDouble(trElement.Children[1].InnerText.Replace(",", ""));
                    double percentage = Convert.ToDouble(trElement.Children[2].InnerText);
                    double high = Convert.ToDouble(trElement.Children[6].InnerText.Replace(",", ""));
                    double low = Convert.ToDouble(trElement.Children[7].InnerText.Replace(",", ""));
                   
                    if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                        PlaceOrder(OrderType.Sell, stock, low);
                    else
                        PlaceOrder(OrderType.Buy, stock, high);
                    
                }
                if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                    loserTextBox.Text += stocks + System.Environment.NewLine;
                else
                    gainerTextBox.Text += stocks + System.Environment.NewLine;

                DisplayInfo("Completed.");

                intervelTimer.Enabled = true;
                refreshBtn.Enabled = true;
                startBtn.Enabled = true;
                workTimeCheckBox.Enabled = true;
                shutdownCheckBox.Enabled = true;

            }
            catch (Exception ex)
            {
                DisplayInfo("Message: " + ex.Message);
                DisplayInfo("Inner Exception: " + ex.InnerException);

                intervelTimer.Enabled = true;
                refreshBtn.Enabled = true;
                startBtn.Enabled = true;
                workTimeCheckBox.Enabled = true;
                shutdownCheckBox.Enabled = true;
            }
        }


        private void PlaceOrder(OrderType orderType, string stock, double price)
        {
            if (IsOrderExist(stock)) return;

            Order o = new Order();
            o.Strategy = Strategy.ORB;
            o.Stock = stock;
            o.DateTime = DateTime.Now;
            o.OrderType = orderType;
            o.BuyPrice = 0;
            o.SellPrice = 0;
            o.Qty = Calc.GetQty(price);
            o.CurrPrice = 0;
            o.ProfitLoss = 0;
            o.TrailingTarget = trailingTrarget;             
            o.TargetPercentage = targetPercent; 
            

            if (orderType == OrderType.Buy)
                o.StopLoss = price - Calc.CalcPercentage(price, stopLossPercent);
            else
                o.StopLoss = price + Calc.CalcPercentage(price, stopLossPercent);

            o.StopLossPercentage = stopLossPercent; // it will calc the SL again after the order placed, based on buy price;
            o.TrailingSL = trailingStopLoss;  
            o.TriggerPrice = price;
            o.OrderStatus = OrderStatus.NotExecuted;                     
            o.ValidUpTo = DateTime.Now.AddMinutes(300);
            o.MailGrpByName = GetMailSubject();
            Orders.MyOrders.Add(o);
        }

        private bool IsOrderExist(string stock)
        {
            foreach (Order executedOrd in Orders.MyOrders)
            {
                if ((executedOrd.Stock == stock) && (executedOrd.Strategy == Strategy.ORB))
                {
                    return true;
                }
            }
            return false;
        }

        private string GetMailSubject()
        {
            return "ORB, " + "Target:" + targetPercent + ", SL:" + stopLossPercent + "TralingTrarget:" + trailingTrarget.ToString() + ", TralingSL:" + trailingStopLoss.ToString();
        }

        private void GetTopperFromMoneyControl()
        {
            var divElement = GetElementsByClassName(webBrowser1, "div", "bsr_table hist_tbl_hm");
            var tableElement = divElement[0].Children[1];
            var tbodyElement = tableElement.Children[1];
            int top = 5;
            MarketTopper mt = new MarketTopper();
            mt.DateAndTime = DateTime.Now;
            for (int i = 0; i < top; i++)
            {

                var trElement = tbodyElement.Children[i];
                var stock = trElement.Children[0].Children[0].Children[0].InnerText;
                var price = Convert.ToDecimal(trElement.Children[3].InnerText.Replace(",", ""));
                var percentage = Convert.ToDecimal(trElement.Children[6].InnerText);

                mt.Toppers.Add("Top_" + (i + 1), new Stock(stock, price,0,0, percentage)); //get high and low is pending
            }
            //pre_MarketTopper = curr_MarketTopper;

            //curr_MarketTopper = mt;
            //if (pre_MarketTopper == null) pre_MarketTopper = mt;

            //CompareTopper();
        }


        private HtmlElement[] GetElementsByClassName(WebBrowser wb, string tagName, string className)
        {
            var l = new List<HtmlElement>();

            var els = webBrowser1.Document.GetElementsByTagName(tagName); // all elems with tag
            foreach (HtmlElement el in els)
            {
                if (el.GetAttribute("className") == className)
                {
                    l.Add(el);
                }
            }

            return l.ToArray();
        }

        private HtmlElement[] GetElementsByClassName(HtmlElement elements, string tagName, string className)
        {
            var l = new List<HtmlElement>();
            var els = elements.GetElementsByTagName(tagName); // all elems with tag
            foreach (HtmlElement el in els)
            {
                if (el.GetAttribute("className") == className)
                {
                    l.Add(el);
                }
            }

            return l.ToArray();
        }




    }
}
