﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace MyTradeSetup
{
    public partial class MainForm : Form
    {
        public static int AppRunningInstanceNo = 0;
        public static int priceActionCounter = 0;
        public MainForm()
        {
            InitializeComponent();
            Communicator.StockHistory.HistoryUpdated += new Common.HistoryUpdated_EventHandler(StockHistory_HistoryUpdated);
            Communicator.StockHistory.ErrorRised += new Common.Error_EventHandler(ErrorRised);
            Communicator.StockPriceFormZerodha.ErrorRised += new Common.Error_EventHandler(ErrorRised);
            Communicator.StockPriceFormGoogleFinance.ErrorRised += new Common.Error_EventHandler(ErrorRised);            
            Communicator.TopGainerLoser.ErrorRised += new Common.Error_EventHandler(ErrorRised);

            AppRunningInstanceNo = GetRunningCount();
            this.Text = "Trade Setup - " + AppRunningInstanceNo.ToString();

            //OrderSettings oSettings = new OrderSettings();
            //oSettings.MdiParent = this;
            //oSettings.Show();
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            Communicator.StockHistory.TestConnection(PriceAction.GetNifty50()[0]);
        }

        void ErrorRised(Exception exception)
        {
            this.Invoke(new Action(() => ErrorHandler.LogError(exception)));
        }

        void StockHistory_HistoryUpdated(string stock, DataTable History15minsDT, DataTable History30minsDT)
        {
            //throw new NotImplementedException();
        }

        public bool IsInOpen(string formName)
        {
            Form[] mdichld = this.MdiChildren;
            if (this.MdiChildren.Length == 0)
            {
                return false;
            }
            foreach (Form selfm in mdichld)
            {
                string str = selfm.Name;
                str = str.IndexOf(formName).ToString();
                if (str != "-1")
                {
                    selfm.BringToFront();
                    return true;
                }
            }
            return false;
        }

        public int OpenCount(string formName)
        {
            int c = 0;
            Form[] mdichld = this.MdiChildren;
            if (this.MdiChildren.Length == 0)
                return c;

            foreach (Form selfm in mdichld)
            {
                string str = selfm.Name;
                str = str.IndexOf(formName).ToString();
                if (str != "-1")
                {
                    c = c + 1;
                }
            }
            return c;
        }

        private void topGainnerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("TopGainer")) return;

            TopGainer tg = new TopGainer();
            tg.MdiParent = this;
            tg.Show();
        }

        private void priceActionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //if (IsInOpen("PriceActionUI")) return;
            priceActionCounter = priceActionCounter + 1;

            PriceActionUI pa = new PriceActionUI();
            pa.MdiParent = this;
            pa.headerText = "Pricte Action(Setting " + priceActionCounter.ToString() + ")";
            pa.Text = pa.headerText;
            pa.headerId = priceActionCounter;
            pa.Show();
        }

        private void ordersToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            //if (IsInOpen("TradeOrderUI")) return;

            //TradeOrderUI to = new TradeOrderUI();
            //to.MdiParent = this;            
            //to.Show();
        }

        private void stockHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("StockHistory")) return;

            StockHistoryUI sh = new StockHistoryUI();
            sh.MdiParent = this;
            sh.Show();
        }

        private void testingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Test t = new Test();
            //t.Show();
        }

        public int GetRunningCount()
        {
            int count = 0;
            string name = "MyTradeSetup";
            foreach (Process clsProcess in Process.GetProcesses())
            {
                if (clsProcess.ProcessName.Contains(name))
                    count++;
            }
            return count;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(DialogResult.No == MessageBox.Show("Do you want to close the application?","Confirmation",MessageBoxButtons.YesNo))
                e.Cancel=true;
        }

        private void oRBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("ORB")) return;

            ORB orb = new ORB();
            orb.MdiParent = this;
            orb.Show();
        }

        private void orderSettingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("OrderSettings")) return; 

            OrderSettings oSettings = new OrderSettings();
            oSettings.MdiParent = this;
            oSettings.Show();
        }

        private void zerodhaLoginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("ZerodhaLogin")) return;

            Zerodha.ZerodhaLogin login = new Zerodha.ZerodhaLogin();
            login.MdiParent = this;
            login.Show();
        }

        private void showErrorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (IsInOpen("ShowError")) return;

            ShowError err = new ShowError();
            err.MdiParent = this;
            err.Show();
        }

        
    }
}
