﻿namespace MyTradeSetup
{
    partial class TradeOrderUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.orderGridHeaderTxt = new System.Windows.Forms.TextBox();
            this.orderDataGridView = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.footerTxtBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // orderGridHeaderTxt
            // 
            this.orderGridHeaderTxt.Dock = System.Windows.Forms.DockStyle.Top;
            this.orderGridHeaderTxt.Enabled = false;
            this.orderGridHeaderTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderGridHeaderTxt.Location = new System.Drawing.Point(0, 0);
            this.orderGridHeaderTxt.Name = "orderGridHeaderTxt";
            this.orderGridHeaderTxt.Size = new System.Drawing.Size(841, 24);
            this.orderGridHeaderTxt.TabIndex = 3;
            this.orderGridHeaderTxt.Text = "Price Action";
            this.orderGridHeaderTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // orderDataGridView
            // 
            this.orderDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.orderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.orderDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.orderDataGridView.Location = new System.Drawing.Point(0, 24);
            this.orderDataGridView.Name = "orderDataGridView";
            this.orderDataGridView.Size = new System.Drawing.Size(841, 311);
            this.orderDataGridView.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.orderDataGridView);
            this.panel1.Controls.Add(this.footerTxtBox);
            this.panel1.Controls.Add(this.orderGridHeaderTxt);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(841, 359);
            this.panel1.TabIndex = 4;
            // 
            // footerTxtBox
            // 
            this.footerTxtBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.footerTxtBox.Enabled = false;
            this.footerTxtBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.footerTxtBox.Location = new System.Drawing.Point(0, 335);
            this.footerTxtBox.Name = "footerTxtBox";
            this.footerTxtBox.Size = new System.Drawing.Size(841, 24);
            this.footerTxtBox.TabIndex = 4;
            this.footerTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TradeOrderUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 359);
            this.Controls.Add(this.panel1);
            this.Name = "TradeOrderUI";
            this.Text = "TradeOrderUI";
            ((System.ComponentModel.ISupportInitialize)(this.orderDataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox orderGridHeaderTxt;
        private System.Windows.Forms.DataGridView orderDataGridView;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox footerTxtBox;
    }
}