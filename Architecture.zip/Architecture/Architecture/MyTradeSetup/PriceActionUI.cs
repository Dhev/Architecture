﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;

namespace MyTradeSetup
{
    public partial class PriceActionUI : Form
    {
        string PriceActionUP;
        string PriceActionDown;
        int timeIntervelInMin;
        public string headerText;
        public int headerId;
        TradeOrderUI tradeOrderUI;
        public static Dictionary<string, int> LogicDictionary = new Dictionary<string, int>();
        public PriceActionUI()
        {
            InitializeComponent();
            radioBtn30min.Checked = true;
            statusLabel.Text = "";
            levelComboBox.SelectedIndex = 1;
            if (Orders.MyOrders == null) Orders.MyOrders = new List<Order>();

            orbCheckBox.Checked = true;
            actionPercentageTextBox.Text = "0.1";
            profitTextBox.Text = "0.3";
            trailingProfit_CheckBox.Checked = false;
            trailingSL_CheckBox.Checked = false;
            stopLossTextBox.Text = "0.6";
            timeIntervelInMin = 15;
            if (radioBtn30min.Checked) timeIntervelInMin = 30;

            removeCandleCheckBox.Checked = true;
            topGainerLosserCheckBox.Checked = true;
            topComboBox.Enabled = true;
            topComboBox.SelectedIndex = 0;
        }

        private void testConnectionBtn_Click(object sender, EventArgs e)
        {
            DataTable dataDT = Communicator.StockHistory.TestConnection(PriceAction.GetNifty50()[0]);
            if (dataDT != null)
            {
                if (dataDT.Rows.Count <= 0)
                    this.Text = ("Failed.Try Gain");
                else
                    this.Text = ("Success");
            }
            else
            {
                this.Text = ("Failed.Try Gain");
            }
        }

        private void startBtn_Click(object sender, EventArgs e)
        {
            if (LogicDictionary.ContainsKey(GetMailSubject()))
            {
                MessageBox.Show("Same setting already running.", "Message", MessageBoxButtons.OK);
                return;
            }
            timeIntervelInMin = 15;
            if (radioBtn30min.Checked) timeIntervelInMin = 30;

            LogicDictionary[GetMailSubject()] = 0;
            panel1.Enabled = false;

            tradeOrderUI = new TradeOrderUI(GetMailSubject(), "Order(Setting" + headerId.ToString() + ")");
            tradeOrderUI.MdiParent = this.MdiParent;
            tradeOrderUI.Show();

            Communicator.StockHistory.HistoryUpdated += new Common.HistoryUpdated_EventHandler(StockHistory_HistoryUpdated);
        }

        void StockHistory_HistoryUpdated(string stock, DataTable History15minsDT, DataTable History30minsDT)
        {
            this.Invoke(new Action(() => LoadData(stock, History15minsDT, History30minsDT)));            
        }
        private void LoadData(string stock, DataTable History15minsDT, DataTable History30minsDT)
        {
            if (stock == "")
            {
                this.Text = headerText + " " + DateTime.Now.ToString("hh:mm:ss tt");
                return;
            }
            DataTable dataDT;
            if (timeIntervelInMin == 15)
                dataDT = History15minsDT;
            else
            {
                if (CheckUpdates())
                    dataDT = History30minsDT;
                else
                {
                    this.Text = "HAHAHA....";
                    return;
                }
            }
            CheckPriceAction(stock, dataDT);
        }

        private DataTable RemoveCandleRows(DataTable dataDT, out double todayHigh, out double todayLow)
        {
            List<DataRow> rowsToDelete = new List<DataRow>();
            todayHigh = 0;
            todayLow = 999999999999;
            foreach (DataRow dr in dataDT.Rows)
            {
                double open = Convert.ToDouble(dr["open"]);
                double close = Convert.ToDouble(dr["close"]);

                double high = Convert.ToDouble(dr["high"]);
                double low = Convert.ToDouble(dr["low"]);

                if (todayHigh < high)
                    todayHigh = high;

                if (todayLow > low)
                    todayLow = low;

                double diff = (open - close);
                if (diff < 0)
                    diff = diff * (-1);

                if (diff < Calc.CalcPercentage(Convert.ToDouble(dr["open"]), Convert.ToDouble(actionPercentageTextBox.Text)))
                {
                    rowsToDelete.Add(dr);
                }
            }
            foreach (DataRow row in rowsToDelete)
            {
                dataDT.Rows.Remove(row);
            }
            return dataDT;
        }

        private void CheckPriceAction(string stock, DataTable dataDT)
        {
            try
            {
                this.Text = headerText + "-Checking Stock " + (PriceAction.GetNifty50().IndexOf(stock) + 1).ToString() + "/" + PriceAction.GetNifty50().Count.ToString() + ": " + stock;
                this.Invalidate();
                this.Refresh();
                

                if (dataDT != null)
                {
                    double todayHigh = 0, todayLow = 0;
                    if (removeCandleCheckBox.Checked)
                    {
                        dataDT = RemoveCandleRows(dataDT, out todayHigh, out todayLow);
                    }
                    if (dataDT.Rows.Count > 0)
                    {
                        DateTime lastRowDT = Convert.ToDateTime(dataDT.Rows[dataDT.Rows.Count - 1][0]);
                        TimeSpan ts = DateTime.Now.Subtract(lastRowDT);
                        if (ts.TotalMinutes < 5) 
                        {
                            PriceAction pc = new PriceAction();
                            Dictionary<string, double> ordPrice;
                            Order o = new Order();

                            if (pc.CheckPriceActionUp(dataDT, Convert.ToInt32(levelComboBox.Text), out ordPrice, Convert.ToDouble(actionPercentageTextBox.Text), orbCheckBox.Checked, todayHigh))
                            {
                                PriceActionUP = PriceActionUP + "," + stock;

                                o.Strategy = Strategy.PriceAction;
                                o.Stock = stock;
                                o.DateTime = DateTime.Now;
                                o.OrderType = OrderType.Buy;
                                o.BuyPrice = 0;
                                o.SellPrice = 0;
                                o.Qty = (int)ordPrice["qty"];
                                o.CurrPrice = 0;
                                o.ProfitLoss = 0;
                                //o.Target = ordPrice["targetPrice"];
                                o.TrailingTarget = trailingProfit_CheckBox.Checked;
                                if (double.Parse(profitTextBox.Text) < ordPrice["targerPercentage"])
                                    o.TargetPercentage = double.Parse(profitTextBox.Text);
                                else
                                    o.TargetPercentage = ordPrice["targerPercentage"];

                                o.StopLoss = ordPrice["slPrice"];
                                if (basedOnPreviousCandleCheckBox.Checked)
                                    o.StopLossPercentage = 0;
                                else
                                    o.StopLossPercentage = double.Parse(stopLossTextBox.Text);

                                o.TriggerPrice = ordPrice["triggerPrice"];
                                o.OrderStatus = OrderStatus.NotExecuted;
                                o.TrailingSL = trailingSL_CheckBox.Checked;
                                o.ValidUpTo = DateTime.Now.AddMinutes(timeIntervelInMin * 20);
                                //o.Detail = "Waiting for Execute";   
                                o.MailGrpByName = GetMailSubject();
                                o.TopGinerLosser = 0;
                                if (topGainerLosserCheckBox.Checked)
                                    o.TopGinerLosser = Convert.ToInt32(topComboBox.Text);

                                //if (o.TrailingSL) o.Target = o.Target + (o.Target / 2); //Always SL will hit in trailing
                            }
                            else if (pc.CheckPriceActionDown(dataDT, Convert.ToInt32(levelComboBox.Text), out ordPrice, Convert.ToDouble(actionPercentageTextBox.Text), orbCheckBox.Checked, todayLow))
                            {
                                PriceActionDown = PriceActionDown + "," + stock;

                                o.Strategy = Strategy.PriceAction;
                                o.Stock = stock;
                                o.DateTime = DateTime.Now;
                                o.OrderType = OrderType.Sell;
                                o.BuyPrice = 0;
                                o.SellPrice = 0;
                                o.Qty = (int)ordPrice["qty"];
                                o.CurrPrice = 0;
                                o.ProfitLoss = 0;
                                //o.Target = ordPrice["targetPrice"];
                                o.TrailingTarget = trailingProfit_CheckBox.Checked;
                                if (double.Parse(profitTextBox.Text) < ordPrice["targerPercentage"])
                                    o.TargetPercentage = double.Parse(profitTextBox.Text);
                                else
                                    o.TargetPercentage = ordPrice["targerPercentage"];

                                o.StopLoss = ordPrice["slPrice"];
                                if (basedOnPreviousCandleCheckBox.Checked)
                                    o.StopLossPercentage = 0;
                                else
                                    o.StopLossPercentage = double.Parse(stopLossTextBox.Text);

                                o.TriggerPrice = ordPrice["triggerPrice"];
                                o.OrderStatus = OrderStatus.NotExecuted;
                                o.TrailingSL = trailingSL_CheckBox.Checked;
                                o.ValidUpTo = DateTime.Now.AddMinutes(timeIntervelInMin * 20);
                                //o.Detail = "Waiting for Execute";
                                o.MailGrpByName = GetMailSubject();
                                o.TopGinerLosser = 0;
                                if (topGainerLosserCheckBox.Checked)
                                    o.TopGinerLosser = Convert.ToInt32(topComboBox.Text);
                                //if (o.TrailingSL) o.Target = o.Target - (o.Target / 2); //Always SL will hit in trailing
                            }

                            if (!String.IsNullOrEmpty(o.Stock))
                            {
                                bool isOrdInProgress = false;
                                foreach (Order executedOrd in Orders.MyOrders)
                                {
                                    if (o.Stock == executedOrd.Stock && o.Strategy == executedOrd.Strategy && executedOrd.MailGrpByName == GetMailSubject())
                                    {
                                        isOrdInProgress = true; //to avoid reenter in the same stock
                                        //if ((executedOrd.OrderStatus == OrderStatus.InProgress) || (executedOrd.OrderStatus == OrderStatus.NotExecuted))
                                        //    isOrdInProgress = true;
                                        //if (executedOrd.OrderStatus == OrderStatus.Completed) //if the order completed with in 15 min, it will gain placed. to avaoid this, this if condition is included
                                        //{
                                        //    if (IsInCurrentCandle(executedOrd.DateTime))
                                        //        isOrdInProgress = true;
                                        //}
                                    }
                                }
                                if (!isOrdInProgress) Orders.MyOrders.Add(o);
                            }


                        }


                    }
                    else
                        logTextBox.AppendText(DateTime.Now.ToString("d/M/yy hh:mm:ss tt") + ": Stock " + stock + " No data." + System.Environment.NewLine);
                }
                else
                    logTextBox.AppendText(DateTime.Now.ToString("d/M/yy hh:mm:ss tt") + ": Stock " + stock + " No data." + System.Environment.NewLine);
            }
            catch (Exception exception)
            {
                ErrorHandler.LogError(exception);
            }
            finally
            {
            }
        }
        
        

        private bool IsInCurrentCandle(DateTime dt)
        {
            if (timeIntervelInMin == 15)
            {
                int priceActionFormedIn = 0;
                if (dt.Minute >= 0 && dt.Second >= 0 && dt.Minute <= 14 && dt.Second <= 59) priceActionFormedIn = 0;
                if (dt.Minute >= 15 && dt.Second >= 0 && dt.Minute <= 29 && dt.Second <= 59) priceActionFormedIn = 15;
                if (dt.Minute >= 30 && dt.Second >= 0 && dt.Minute <= 44 && dt.Second <= 59) priceActionFormedIn = 30;
                if (dt.Minute >= 45 && dt.Second >= 0 && dt.Minute <= 59 && dt.Second <= 59) priceActionFormedIn = 45;

                //DateTime priceActionCandle= new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day,dt.Hour,priceActionFormedIn,0,0);
                DateTime priceActionNextCandle;
                if (priceActionFormedIn == 45)
                    priceActionNextCandle = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour + 1, 0, 0, 0);
                else
                    priceActionNextCandle = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour, priceActionFormedIn+15, 0, 0);

                if (DateTime.Now > priceActionNextCandle)
                    return false;
                else
                    return true;
            }
            if (timeIntervelInMin == 30)
            {
                int priceActionFormedIn = 0;
                if (dt.Minute >= 15 && dt.Second >= 0 && dt.Minute <= 44 && dt.Second <= 59) priceActionFormedIn = 15;
                if (dt.Minute >= 45 && dt.Second >= 0 && dt.Minute <= 59 && dt.Second <= 59) priceActionFormedIn = 45;
                if (dt.Minute >= 0 && dt.Second >= 0 && dt.Minute <= 14 && dt.Second <= 59) priceActionFormedIn = 45;

                //DateTime priceActionCandle= new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day,dt.Hour,priceActionFormedIn,0,0);
                DateTime priceActionNextCandle;
                if (priceActionFormedIn == 45)
                    priceActionNextCandle = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour + 1, 15, 0, 0);
                else
                    priceActionNextCandle = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, dt.Hour, priceActionFormedIn + 30, 0, 0);

                if (DateTime.Now > priceActionNextCandle)
                    return false;
                else
                    return true;
            }
            return false;
        }

        private string GetMailSubject()
        {
            string sl = "";
            if (basedOnPreviousCandleCheckBox.Checked)
                sl = "BPC";
            else
                sl = stopLossTextBox.Text;

            string intervel = "15mins";
            if (radioBtn30min.Checked)
                intervel = "30mins";

            
            string rtn = "Price Action-Intervel:" + intervel + ", Level:" + levelComboBox.Text + ", Action%:" + actionPercentageTextBox.Text + ", ORB:" + orbCheckBox.Checked.ToString() + ", Profit%:" + profitTextBox.Text.ToString() + ", Trailing Profit:" + trailingProfit_CheckBox.Checked.ToString() + ", SL(%):" + sl + ", Trailing SL:" + trailingSL_CheckBox.Checked.ToString() + ", Remove Small Candle:" + removeCandleCheckBox.Checked.ToString();

            rtn = rtn + ", Must be Top Gainer/Loser:" + topGainerLosserCheckBox.Checked.ToString();
            rtn = rtn + ", Top:" + topComboBox.Text;
            return rtn;
        }

        private void actionPercentageTextBox_Leave(object sender, EventArgs e)
        {
            double temp;
            if (double.TryParse(actionPercentageTextBox.Text,out temp) == false)
            {
                MessageBox.Show("Enter a Valid Action Percentage");
                actionPercentageTextBox.Focus();
            }
            else if (Convert.ToDouble(actionPercentageTextBox.Text) < 0)
            {
                MessageBox.Show("Enter a positive Action Percentage");
                actionPercentageTextBox.Focus();
            }
            else if (Convert.ToDouble(actionPercentageTextBox.Text) >100)
            {
                MessageBox.Show("Enter a Valid Action Percentage");
                actionPercentageTextBox.Focus();
            }
        }

        private void profitTextBox_Leave(object sender, EventArgs e)
        {
            double temp;
            if (double.TryParse(profitTextBox.Text, out temp) == false)
            {
                MessageBox.Show("Enter a Valid Profit Percentage");
                profitTextBox.Focus();
            }
            else if (Convert.ToDouble(profitTextBox.Text) < 0.2)
            {
                MessageBox.Show("Enter a positive Profit Percentage");
                profitTextBox.Focus();
            }
            else if (Convert.ToDouble(profitTextBox.Text)>100)
            {
                MessageBox.Show("Enter a Valid Profit Percentage");
                profitTextBox.Focus();
            }

        }

        private void stopLossTextBox_Leave(object sender, EventArgs e)
        {
            double temp;
            if (double.TryParse(stopLossTextBox.Text, out temp) == false)
            {
                MessageBox.Show("Enter a Valid Stop Loss Percentage");
                stopLossTextBox.Focus();
            }
            else if (Convert.ToDouble(stopLossTextBox.Text) < 0.3)
            {
                MessageBox.Show("Enter a positive Stop Loss Percentage");
                stopLossTextBox.Focus();
            }
            else if (Convert.ToDouble(stopLossTextBox.Text) > 100)
            {
                MessageBox.Show("Enter a Valid Stop Loss Percentage");
                stopLossTextBox.Focus();
            }
        }

        private void basedOnPreviousCandleCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            
            stopLossTextBox.Enabled = false;
            if (basedOnPreviousCandleCheckBox.Checked==false)
            {
                stopLossTextBox.Enabled = true;
                stopLossTextBox.Text = "0.3";
            }
        }

        private bool CheckUpdates()
        {
            int min = DateTime.Now.Minute;
            int sec = DateTime.Now.Second;
            if (timeIntervelInMin == 15)
            {
                if ((min == 15) && (sec >= 15)) return true;
                if ((min >= 16) && (min <= 18)) return true;

                if ((min == 30) && (sec >= 15)) return true;
                if ((min >= 31) && (min <= 33)) return true;

                if ((min == 45) && (sec >= 15)) return true;
                if ((min >= 46) && (min <= 48)) return true;

                if ((min == 0) && (sec >= 15)) return true;
                if ((min >= 1) && (min <= 3)) return true;
                
            }
            if (timeIntervelInMin == 30)
            {
                if ((min == 15) && (sec >= 15)) return true;
                if ((min >= 16) && (min <= 18)) return true;

                if ((min == 45) && (sec >= 15)) return true;
                if ((min >= 46) && (min <= 48)) return true;               
            }
            
            //this.Text = headerText + " " + DateTime.Now.ToString("hh:mm:ss tt");
            return false;
        }

        private void PriceActionUI_FormClosing(object sender, FormClosingEventArgs e)
        {
            LogicDictionary.Remove(GetMailSubject());
            Communicator.StockHistory.HistoryUpdated -= new Common.HistoryUpdated_EventHandler(this.StockHistory_HistoryUpdated);
        }

        private void topGainerLosserCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (topGainerLosserCheckBox.Checked)
                topComboBox.Enabled = true;
            else
                topComboBox.Enabled = false;
        }

    }
}
