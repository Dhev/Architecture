﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using System.Data;

namespace MyTradeSetup
{
    public static class Communicator
    {
        public static IStockPrice StockPriceFormGoogleFinance = new GoogleFinance.StockPrice();
        public static IStockPrice StockPriceFormZerodha = new Zerodha.StockPrice();
        public static IStockHistory StockHistory = new GoogleFinance.StockHistory(PriceAction.GetNifty50());
        public static IOrder ZerodhaOrder = new Zerodha.Order();
        public static Common.ITopGainerLoser TopGainerLoser = new GoogleFinance.TopGainerLoser();
    }
}
