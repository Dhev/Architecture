﻿namespace MyTradeSetup
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.setupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.priceActionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zerodhaLoginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showErrorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.topGainnerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oRBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.setupToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(284, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // setupToolStripMenuItem
            // 
            this.setupToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.priceActionToolStripMenuItem,
            this.zerodhaLoginToolStripMenuItem,
            this.orderSettingsToolStripMenuItem,
            this.showErrorsToolStripMenuItem,
            this.stockHistoryToolStripMenuItem,
            this.topGainnerToolStripMenuItem,
            this.oRBToolStripMenuItem,
            this.testingToolStripMenuItem});
            this.setupToolStripMenuItem.Name = "setupToolStripMenuItem";
            this.setupToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.setupToolStripMenuItem.Text = "&Setup";
            // 
            // priceActionToolStripMenuItem
            // 
            this.priceActionToolStripMenuItem.Name = "priceActionToolStripMenuItem";
            this.priceActionToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.priceActionToolStripMenuItem.Text = "Price Action";
            this.priceActionToolStripMenuItem.Click += new System.EventHandler(this.priceActionToolStripMenuItem_Click);
            // 
            // zerodhaLoginToolStripMenuItem
            // 
            this.zerodhaLoginToolStripMenuItem.Name = "zerodhaLoginToolStripMenuItem";
            this.zerodhaLoginToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.zerodhaLoginToolStripMenuItem.Text = "Zerodha Login";
            this.zerodhaLoginToolStripMenuItem.Click += new System.EventHandler(this.zerodhaLoginToolStripMenuItem_Click);
            // 
            // orderSettingsToolStripMenuItem
            // 
            this.orderSettingsToolStripMenuItem.Name = "orderSettingsToolStripMenuItem";
            this.orderSettingsToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.orderSettingsToolStripMenuItem.Text = "Order Settings";
            this.orderSettingsToolStripMenuItem.Click += new System.EventHandler(this.orderSettingsToolStripMenuItem_Click);
            // 
            // showErrorsToolStripMenuItem
            // 
            this.showErrorsToolStripMenuItem.Name = "showErrorsToolStripMenuItem";
            this.showErrorsToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.showErrorsToolStripMenuItem.Text = "Show Errors";
            this.showErrorsToolStripMenuItem.Click += new System.EventHandler(this.showErrorsToolStripMenuItem_Click);
            // 
            // stockHistoryToolStripMenuItem
            // 
            this.stockHistoryToolStripMenuItem.Name = "stockHistoryToolStripMenuItem";
            this.stockHistoryToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.stockHistoryToolStripMenuItem.Text = "Stock History";
            this.stockHistoryToolStripMenuItem.Click += new System.EventHandler(this.stockHistoryToolStripMenuItem_Click);
            // 
            // topGainnerToolStripMenuItem
            // 
            this.topGainnerToolStripMenuItem.Name = "topGainnerToolStripMenuItem";
            this.topGainnerToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.topGainnerToolStripMenuItem.Text = "Top Gainer";
            this.topGainnerToolStripMenuItem.Click += new System.EventHandler(this.topGainnerToolStripMenuItem_Click);
            // 
            // oRBToolStripMenuItem
            // 
            this.oRBToolStripMenuItem.Name = "oRBToolStripMenuItem";
            this.oRBToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.oRBToolStripMenuItem.Text = "ORB";
            this.oRBToolStripMenuItem.Click += new System.EventHandler(this.oRBToolStripMenuItem_Click);
            // 
            // testingToolStripMenuItem
            // 
            this.testingToolStripMenuItem.Name = "testingToolStripMenuItem";
            this.testingToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.testingToolStripMenuItem.Text = "Testing";
            this.testingToolStripMenuItem.Click += new System.EventHandler(this.testingToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Trade Setup";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem setupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem topGainnerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem priceActionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oRBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zerodhaLoginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showErrorsToolStripMenuItem;
    }
}

