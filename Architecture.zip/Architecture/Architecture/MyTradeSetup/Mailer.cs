﻿using System.Collections.Generic;
using System.Net.Mail;

namespace MyTradeSetup
{
    public class Mailer
    {
      //  private string host = "smtp.gmail.com";
        //private string tomail = "ssvelu83@gmail.com,hellodhev@gmail.com,rveerarajan@gmail.com,charu.aarthy@gmail.com,dkumaresh@gmail.com,nepoleon.jayarajan@gmail.com";
       // private string tomail = "hellotraders123@googlegroups.com";
        //private string tomail = "ssvelu83@gmail.com";
        private string cc = "";
        private string bcc = ""; 

        public Mailer()
        {
           
        }

        public void SendMail(string subject, string body, string[] attachmentPath, bool enableSsl)
        {
            //Thread mailThread = new Thread(delegate() 
            //{ 
                //TriggerMail(subject, body, attachmentPath, enableSsl); 
            //});
            //mailThread.Start();

            TriggerMail(subject, body, attachmentPath, enableSsl);
        }

        private void TriggerMail(string subject, string body, string[] attachmentPath, bool enableSsl)
        {
            using (MailMessage mail = new MailMessage())
            {
                //mail.From = new MailAddress(frommail);

             //   if (tomail != null)
             //   {
             //       string[] toAdds = tomail.Split(',');
             //       for (int i = 0; i < toAdds.GetLength(0); i++)
             //       {
             //           if (toAdds[i].Trim() != "")
             //               mail.To.Add(toAdds[i]);
             //       }
             //   }

             //   if (cc != null)
             //   {
             //       string[] ccAdds = cc.Split(',');
             //       for (int i = 0; i < ccAdds.GetLength(0); i++)
             //       {
             //           if (ccAdds[i].Trim() != "")
             //               mail.CC.Add(ccAdds[i]);
             //       }
             //   }

             //   if (bcc != null)
             //   {
             //       string[] bccAdds = bcc.Split(',');
             //       for (int i = 0; i < bccAdds.GetLength(0); i++)
             //       {
             //           if (bccAdds[i].Trim() != "")
             //               mail.Bcc.Add(bccAdds[i]);
             //       }
             //   }


             //   mail.Subject = System.Environment.MachineName+": "+ subject;
             ////   mail.Body = body + "<html><body><br/>Regards,<br/>S.Suresh<br/>Cell: 9789865522<br/>Email: <a href='mailto:ssvelu83@gmail.com'>ssvelu83@gmail.com</a></body></html>";
             //   if (attachmentPath != null)
             //   {
             //       foreach (string att_Path in attachmentPath)
             //       {
             //           if (att_Path.Trim() != "")
             //               mail.Attachments.Add(new Attachment(att_Path));
             //       }
             //   }
             //   //if (attach_Memory_Stream != null)
             //   //{
             //   //    foreach (Attach_Memory_Stream att in attach_Memory_Stream)
             //   //    {
             //   //        mail.Attachments.Add(new Attachment(att.Memory_Stream, att.File_Name, att.Media_Type));
             //   //    }
             //   //}


             //   mail.IsBodyHtml = true;
             //   SMPTMailSend(mail, enableSsl, 0);
            }
        }

        private void SMPTMailSend(MailMessage mail,bool enableSsl,int mailerIndex)
        {
            //try
            //{

            //    string fromEmail = MailSenders()[mailerIndex][0];
            //    string pass = MailSenders()[mailerIndex][1];

            //    mail.From = new MailAddress(fromEmail);
            //    SmtpClient SmtpServer = new SmtpClient(host, 587);
            //    //SmtpServer.Port = 587;
            //    SmtpServer.UseDefaultCredentials = false;
            //    SmtpServer.Credentials = new System.Net.NetworkCredential(fromEmail, pass);
            //    SmtpServer.EnableSsl = enableSsl;
            //    SmtpServer.Send(mail);
            //}
            //catch(Exception e)
            //{
            //    if (e.Message.ToLower().Contains("quota exceeded"))
            //    {
            //        mailerIndex = mailerIndex + 1;
            //        SMPTMailSend(mail, enableSsl, mailerIndex);
            //    }
            //    else
            //    {
            //        throw new Exception(e.Message, e.InnerException);
            //    }
            //}
        }

        public static Dictionary<int, string[]> MailSenders()
        {
            Dictionary<int, string[]> mailSenders = new Dictionary<int, string[]>();
            //mailSenders.Add(0, new string[] { "mysysteminfo.suresh@gmail.com", "password-1" });
            //mailSenders.Add(1, new string[] { "suresh101983@gmail.com", "password-1" });

            return mailSenders;
        }
    }

}

