﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace MyTradeSetup
{
    public class PriceAction
    {
        public bool CheckPriceActionUp(DataTable dataDT, int levels, out Dictionary<string, double> ordPrice, double actionPercentage, bool checkORB, double todayHigh)
        {
            ordPrice = new Dictionary<string, double>();
            levels = levels - 1;
            if (levels > dataDT.Rows.Count) return false;
            for (int i = levels; i > 1; i--)
            {
                int rowNo1 = (dataDT.Rows.Count - i);
                int rowNo2 = (dataDT.Rows.Count - i) + 1;
                StockPrice sp1 = new StockPrice();
                StockPrice sp2 = new StockPrice();
                GetRowData(dataDT, rowNo1, rowNo2, out sp1, out sp2);
                if ((sp1.Open >= sp1.Close) || (sp2.Open >= sp2.Close)) return false; //must be green candle
                if ((sp1.Close - sp1.Open) <= calcPercentageOfPriceMovement(sp1.Open, actionPercentage)) return false; //Candle body must be greater than action % 
                if ((sp2.Close - sp2.Open) <= calcPercentageOfPriceMovement(sp2.Open, actionPercentage)) return false; //Candle body must be greater than action % 
                if (sp1.Low >= sp2.Low) return false;
                if (sp1.High >= sp2.High) return false;
                if ((sp2.High - sp1.High) <= calcPercentageOfPriceMovement(sp1.High, actionPercentage)) return false;
             

                
                //double calcTarget = calcPercentageBasedOnInvestment(sp2.High, OrderType.Buy, 0.5);
                //if ((sp2.High + (sp2.High - sp2.Low)) < calcTarget)
                //{
                //    ordPrice["targetPrice"] = sp2.High + (sp2.High - sp2.Low);
                //}
                //else
                //{
                //    ordPrice["targetPrice"] = calcTarget;
                //}
                ordPrice["slPrice"] = sp2.Low;
                //if (sp2.High + (calcPercentageOfPriceMovement(sp2.High, 0.1)) < ordPrice["targetPrice"])
                //{
                //    ordPrice["triggerPrice"] = sp2.High + (calcPercentageOfPriceMovement(sp2.High, 0.1));
                //}
                //else
                //{
                //    ordPrice["triggerPrice"] = sp2.High;
                //}
                ordPrice["triggerPrice"] = sp2.High;

                if (checkORB)
                    ordPrice["triggerPrice"] = todayHigh;

                ordPrice["qty"] = GetQty(ordPrice["triggerPrice"]);

                ordPrice["targerPercentage"] = (((sp2.High - sp2.Low) / sp2.High) * 100);
                if (ordPrice["targerPercentage"] < 0.2) return false;
                //if (ordPrice["triggerPrice"] >= ordPrice["targetPrice"]) return false;
                //if (ordPrice["slPrice"] >= ordPrice["triggerPrice"]) return false;
                
            }
            return true;
        }

        public bool CheckPriceActionDown(DataTable dataDT, int levels, out Dictionary<string, double> ordPrice, double actionPercentage, bool checkORB,double todayLow)
        {
            ordPrice = new Dictionary<string, double>();
            levels = levels - 1;
            if (levels > dataDT.Rows.Count) return false;
            for (int i = levels; i > 1; i--)
            {
                int rowNo1 = (dataDT.Rows.Count - i);
                int rowNo2 = (dataDT.Rows.Count - i) + 1;
                StockPrice sp1 = new StockPrice();
                StockPrice sp2 = new StockPrice();
                GetRowData(dataDT, rowNo1, rowNo2, out sp1, out sp2);
                if ((sp1.Open <= sp1.Close) || (sp2.Open <= sp2.Close)) return false; //must be red candle
                if ((sp1.Open - sp1.Close) <= calcPercentageOfPriceMovement(sp1.Open, actionPercentage)) return false; //Candle body must be greater than action % 
                if ((sp2.Open - sp2.Close) <= calcPercentageOfPriceMovement(sp2.Open, actionPercentage)) return false; //Candle body must be greater than action % 
                if (sp1.Low <= sp2.Low) return false;
                if (sp1.High <= sp2.High) return false;
                if ((sp1.Low - sp2.Low) <= calcPercentageOfPriceMovement(sp1.Low, actionPercentage)) return false;

               
                //double calcTarget = calcPercentageBasedOnInvestment(sp2.Low, OrderType.Sell, 0.5);
                //if ((sp2.Low - (sp2.High - sp2.Low)) > calcTarget)
                //{
                //    ordPrice["targetPrice"] = sp2.Low - (sp2.High - sp2.Low);
                //}
                //else
                //{
                //    ordPrice["targetPrice"] = calcTarget;
                //}
                ordPrice["slPrice"] = sp2.High;
                //if (sp2.Low + (calcPercentageOfPriceMovement(sp2.Low,0.1)) > ordPrice["targetPrice"])
                //{
                //    ordPrice["triggerPrice"] = sp2.Low - (calcPercentageOfPriceMovement(sp2.Low, 0.1));
                //}
                //else
                //{
                //    ordPrice["triggerPrice"] = sp2.Low;
                //}
                ordPrice["triggerPrice"] = sp2.Low;

                if (checkORB)
                    ordPrice["triggerPrice"] = todayLow;

                ordPrice["qty"] = GetQty(ordPrice["triggerPrice"]);

                ordPrice["targerPercentage"] = (((sp2.High - sp2.Low) / sp2.Low) * 100);
                if (ordPrice["targerPercentage"] < 0.2) return false;
                //if (ordPrice["triggerPrice"] <= ordPrice["targetPrice"]) return false;
                //if (ordPrice["slPrice"] <= ordPrice["triggerPrice"]) return false;
            }
            return true;
        }

        //private double GetORBPrice(DataTable dataDT, double triggerPrice, string type)
        //{
        //    double orbTiggerPrice = 0;
        //    if (type.ToUpper() == "BUY")
        //        orbTiggerPrice = 0;
        //    else if (type.ToUpper() == "SELL")
        //        orbTiggerPrice = 999999999999;

        //    foreach (DataRow dr in dataDT.Rows)
        //    {
        //        if (type.ToUpper() == "BUY")
        //        {
        //            if (Convert.ToDouble(dr["high"]) > orbTiggerPrice)
        //                orbTiggerPrice = Convert.ToDouble(dr["high"]);
        //        }
        //        else if (type.ToUpper() == "SELL")
        //        {
        //            if (Convert.ToDouble(dr["low"]) < orbTiggerPrice)
        //                orbTiggerPrice = Convert.ToDouble(dr["low"]);
        //        }
                
        //    }
        //    if (type.ToUpper() == "BUY")
        //    {
        //        if (orbTiggerPrice > 0)
        //            return orbTiggerPrice;
        //        else
        //            return triggerPrice;
        //    }
        //    else
        //    {
        //        if (orbTiggerPrice < 999999999999)
        //            return orbTiggerPrice;
        //        else
        //            return triggerPrice;
        //    }
        //}

        private double calcPercentageOfPriceMovement(double low,double percentage)
        {
            return (percentage / 100) * low;
        }

        private double calcPercentageBasedOnInvestment(double price, OrderType ordType, double percentage)
        {            
            double profitAmt = (percentage / 100) * AppConfig.InvestmentAmt;
            double invest_Profit_Tot = 0;
            if (ordType == OrderType.Buy)
                invest_Profit_Tot = AppConfig.InvestmentAmt + profitAmt;
            else
                invest_Profit_Tot = AppConfig.InvestmentAmt - profitAmt;
            double target = Math.Round((invest_Profit_Tot / AppConfig.InvestmentAmt) * price, 2);
            return target;
        }

        private int GetQty(double price)
        {
            return (int)Math.Round(AppConfig.InvestmentAmt / price, 0);
        }

        public void GetRowData(DataTable dataDT, int rowNo1, int rowNo2, out StockPrice sp1, out StockPrice sp2) //move this method to util
        {
            sp1 = new StockPrice();
            sp1.Open = Convert.ToDouble(dataDT.Rows[rowNo1]["open"]);
            sp1.Close = Convert.ToDouble(dataDT.Rows[rowNo1]["close"]);
            sp1.High = Convert.ToDouble(dataDT.Rows[rowNo1]["high"]);
            sp1.Low = Convert.ToDouble(dataDT.Rows[rowNo1]["low"]);

            sp2 = new StockPrice();
            sp2.Open = Convert.ToDouble(dataDT.Rows[rowNo2]["open"]);
            sp2.Close = Convert.ToDouble(dataDT.Rows[rowNo2]["close"]);
            sp2.High = Convert.ToDouble(dataDT.Rows[rowNo2]["high"]);
            sp2.Low = Convert.ToDouble(dataDT.Rows[rowNo2]["low"]);

        }
 
       


       
        public static List<string> GetNifty50()
        {
            List<string> nifty = new List<string>();
            nifty.Add("IOC"); //API return data only if IOC in first
            nifty.Add("ACC");
            nifty.Add("ADANIPORTS");
            nifty.Add("AMBUJACEM");
            nifty.Add("ASIANPAINT");
            nifty.Add("AUROPHARMA");
            nifty.Add("AXISBANK");
            nifty.Add("BAJAJ-AUTO");
            nifty.Add("BANKBARODA");
            nifty.Add("BPCL");
            nifty.Add("INFRATEL");
            nifty.Add("BOSCHLTD");
            nifty.Add("CIPLA");
            nifty.Add("COALINDIA");
            nifty.Add("DRREDDY");
            nifty.Add("EICHERMOT");
            nifty.Add("GAIL");
            nifty.Add("HCLTECH");
            nifty.Add("HDFCBANK");
            nifty.Add("HEROMOTOCO");
            nifty.Add("HINDALCO");
            nifty.Add("HINDUNILVR");
            nifty.Add("HDFC");
            nifty.Add("ITC");
            nifty.Add("ICICIBANK");
            nifty.Add("IBULHSGFIN");
            nifty.Add("INDUSINDBK");
            nifty.Add("INFY");
            nifty.Add("KOTAKBANK");
            nifty.Add("LT");
            nifty.Add("LUPIN");
            nifty.Add("M%26M");
            nifty.Add("MARUTI");
            nifty.Add("NTPC");
            nifty.Add("ONGC");
            nifty.Add("POWERGRID");
            nifty.Add("RELIANCE");
            nifty.Add("SBIN");
            nifty.Add("SUNPHARMA");
            nifty.Add("TCS");
            nifty.Add("TATAMTRDVR");
            nifty.Add("TATAMOTORS");
            nifty.Add("TATAPOWER");
            nifty.Add("TATASTEEL");
            nifty.Add("TECHM");
            nifty.Add("ULTRACEMCO");
            nifty.Add("VEDL");
            nifty.Add("WIPRO");
            nifty.Add("YESBANK");
            nifty.Add("ZEEL");
            nifty.Add("NIFTY");
            return nifty;
        }
    }

    public class StockPrice  // move this to util
    {
        public double Open { get; set; }
        public double Close { get; set; }
        public double High { get; set; }
        public double Low { get; set; }
    }
}
