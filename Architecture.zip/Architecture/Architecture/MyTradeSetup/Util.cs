﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTradeSetup
{
    public class MarketTopper
    {
        public DateTime DateAndTime { get; set; }
        public Dictionary<string, Stock> Toppers { get; set; }
        public MarketTopper()
        {
            Toppers = new Dictionary<string, Stock>();
        }

        public static void CopyMarketTopper(MarketTopper fromMT, out MarketTopper toMT)
        {
            toMT = new MarketTopper();
            toMT.DateAndTime = fromMT.DateAndTime;
            int count = fromMT.Toppers.Count();
            for (int i = 1; i <= count; i++)
            {
                string key= "Top_" + i;
                Stock s = fromMT.Toppers[key];
                toMT.Toppers.Add(key, new Stock(s.Name, s.Price, s.High, s.Low, s.Percentage));
            }
        }
    }

   

    public class Stock
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Percentage { get; set; }
        public Stock(string Name, decimal Price, decimal High, decimal Low, decimal Percentage)
        {
            this.Name = Name;
            this.Price = Price;
            this.High = High;
            this.Low = Low;
            this.Percentage = Percentage;
        }
    }


    public enum API
    {
        GoogleFinance,
        Zerodha
    }

}
