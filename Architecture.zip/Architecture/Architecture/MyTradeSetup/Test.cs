﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace MyTradeSetup
{
    public partial class Test : Form
    {
        private OrderStatus orderStatus;
        private double profitLoss { get; set; }
        private Strategy Strategy { get; set; }
        private DateTime DateTime { get; set; }
        private string Stock { get; set; }
        private OrderType OrderType { get; set; }
        private double BuyPrice { get; set; }
        private double SellPrice { get; set; }
        private int Qty { get; set; }
        private double CurrPrice { get; set; }
        private double ProfitLoss { get { return profitLoss; } set { profitLoss = value;} }
        private double PLPercentage { get; set; }
        private double TriggerPrice { get; set; }
        private double Target { get; set; }
        private double StopLoss { get; set; }
        private OrderStatus OrderStatus { get { return orderStatus; } set { orderStatus = value; } }
        private bool TrailingSL { get; set; }
        private double TrailingSLPrice { get; set; }
        private DateTime ValidUpTo { get; set; }
        private string Detail { get; set; }
        private string MailGrpByName { get; set; }

        Order o = new Order();
        public Test()
        {
            InitializeComponent();
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            Strategy = Strategy.PriceAction;
            Stock = "Testing";
            DateTime = DateTime.Now;
            OrderType = OrderType.Sell;
            BuyPrice = 0;
            SellPrice = 610.1;
            Qty = 164;
            CurrPrice = 607.1;
            ProfitLoss = 0;
            TriggerPrice = 610.1892;
            Target = 607.75;
            StopLoss = 615.7;
            
            OrderStatus = OrderStatus.InProgress;
            TrailingSL = true;
            ValidUpTo = DateTime.Now.AddMinutes(1 * 2);
            //Detail = "Waiting for Execute";

            Sell();

            CurrPrice = 605.1;
            Sell();
            CurrPrice = 604.1;
            Sell();
            CurrPrice = 603.1;
            Sell();
        }

        private void Sell()
        {
            this.ProfitLoss = o.CalcProfitLoss(this.CurrPrice, this.SellPrice, this.Qty);

            if (this.TrailingSLPrice <= 0) this.TrailingSLPrice = this.SellPrice;

            if ((TrailingSL) && (this.CurrPrice < this.TrailingSLPrice))
            {
                double diff = this.TrailingSLPrice - this.CurrPrice;
                if (diff >= o.calcPercentageOfPrice(this.CurrPrice))
                {
                    //UpdateDetail("P&L-Updated.diff" + diff.ToString());
                    //this.Target = this.Target - calcPercentageOfPrice(this.CurrPrice);
                    //this.StopLoss = this.StopLoss - calcPercentageOfPrice(this.CurrPrice);    

                    this.Target = this.Target - diff;
                    this.StopLoss = this.StopLoss - diff;

                    if (this.StopLoss < this.SellPrice)
                    {
                        if (this.StopLoss > (this.CurrPrice + (o.calcPercentageOfPrice(this.CurrPrice) * 3)))
                            this.StopLoss = (this.CurrPrice + (o.calcPercentageOfPrice(this.CurrPrice) * 3));
                    }
                    this.TrailingSLPrice = this.CurrPrice;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        
        }
    }
}
