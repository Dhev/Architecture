﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace MyTradeSetup
{
    public class FileHandler
    {
        public void FileWrite(string path, string[] lines)
        {
            System.IO.File.AppendAllLines(path, lines);
        }

        public void WriteTodayOrdersInFile(string data, string FileName, bool append)
        {
            string orderDirName = AppDomain.CurrentDomain.BaseDirectory + DateTime.Now.ToString("yyyyMMdd");
            string orderFileName = AppDomain.CurrentDomain.BaseDirectory + DateTime.Now.ToString("yyyyMMdd") + @"\Order_" + MainForm.AppRunningInstanceNo.ToString() +"_"+ FileName + ".html";
            if (Directory.Exists(orderDirName) == false)
            {
                Directory.CreateDirectory(orderDirName);
            }
            if (append)
                System.IO.File.AppendAllText(orderFileName, data);
            else
                System.IO.File.WriteAllText(orderFileName, data);
        }
    }
}
