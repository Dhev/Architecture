﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace MyTradeSetup
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();

            Application.SetCompatibleTextRenderingDefault(false);

            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
           
            Application.Run(new MainForm());
        }
        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            try
            {
                List<string> err = new List<string>();
                err.Add("Unhandled Thread Exception");
                err.Add("ErrorMessage: " + e.Exception.Message);
                //string Source = exception.Source;                
                err.Add("StackTrace: " + e.Exception.StackTrace);
                //string Target = exception.TargetSite.ToString();
                if (e.Exception.InnerException != null)
                    err.Add("InnerException: " + e.Exception.InnerException.Message);
                ErrorHandler.LogError(err);
            }
            catch
            {
            }
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            try
            {
                Exception ex = e.ExceptionObject as Exception;

                List<string> err = new List<string>();
                err.Add("Unhandled UI Exception");
                err.Add("ErrorMessage: " + ex.Message);
                //string Source = exception.Source;                
                err.Add("StackTrace: " + ex.StackTrace);
                //string Target = exception.TargetSite.ToString();
                if (ex.InnerException != null)
                    err.Add("InnerException: " + ex.InnerException.Message);
                ErrorHandler.LogError(err);
            }
            catch
            {
            }
        }

    }
}
