﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Common;

namespace MyTradeSetup
{

    public class ExternalErrorHandler : IErrorHandler
    {
        public void LogError(List<string> error)
        {
            ErrorHandler.LogError(error);
        }
    }
    public static class ErrorHandler 
    {
        private static string errorFileDir = AppDomain.CurrentDomain.BaseDirectory + DateTime.Now.ToString("yyyyMMdd");
        private static string errorFileName = AppDomain.CurrentDomain.BaseDirectory + DateTime.Now.ToString("yyyyMMdd") + @"\Error_" + MainForm.AppRunningInstanceNo.ToString() + ".txt";
        public static List<List<string>> ErrorList = new List<List<string>>();
        public static void LogError(Exception exception)
        {
            List<string> err = new List<string>();
            err.Add("ErrorMessage: " + exception.Message);
            //string Source = exception.Source;
            err.Add("StackTrace: " + exception.StackTrace);
            //string Target = exception.TargetSite.ToString();
            if (exception.InnerException != null)
                err.Add("InnerException: " + exception.InnerException.Message);
            ErrorHandler.LogError(err);
        }

        public static void LogError(List<string> error)
        {
            ErrorList.Add(error);
            try
            {
                if (Directory.Exists(errorFileDir) == false)
                {
                    Directory.CreateDirectory(errorFileDir);
                }
                using (StreamWriter writer = File.AppendText(errorFileName))
                {
                    writer.WriteLine("------------------------------------------------------------------------------------");
                    writer.WriteLine("Machine Name: " + System.Environment.MachineName);
                    writer.WriteLine("Date Time: " + DateTime.Now);
                    foreach (string err in error)
                    {
                        writer.WriteLine(err);
                    }
                    writer.WriteLine("------------------------------------------------------------------------------------");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
        }

    }

}
