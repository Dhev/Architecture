﻿namespace MyTradeSetup
{
    partial class OrderSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.profitTxtBox = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusLbl = new System.Windows.Forms.Label();
            this.liveOrderCheckBox = new System.Windows.Forms.CheckBox();
            this.googleRadioBtn = new System.Windows.Forms.RadioButton();
            this.zerodhaRadioBtn = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Close all orders when total profit is :";
            // 
            // profitTxtBox
            // 
            this.profitTxtBox.Location = new System.Drawing.Point(390, 27);
            this.profitTxtBox.Name = "profitTxtBox";
            this.profitTxtBox.Size = new System.Drawing.Size(58, 20);
            this.profitTxtBox.TabIndex = 0;
            this.profitTxtBox.Text = "2000";
            this.profitTxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.profitTxtBox.Leave += new System.EventHandler(this.profitTxtBox_Leave);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // statusLbl
            // 
            this.statusLbl.AutoSize = true;
            this.statusLbl.Location = new System.Drawing.Point(12, 55);
            this.statusLbl.Name = "statusLbl";
            this.statusLbl.Size = new System.Drawing.Size(16, 13);
            this.statusLbl.TabIndex = 2;
            this.statusLbl.Text = "...";
            // 
            // liveOrderCheckBox
            // 
            this.liveOrderCheckBox.AutoSize = true;
            this.liveOrderCheckBox.BackColor = System.Drawing.SystemColors.Control;
            this.liveOrderCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.liveOrderCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liveOrderCheckBox.Location = new System.Drawing.Point(454, 29);
            this.liveOrderCheckBox.Name = "liveOrderCheckBox";
            this.liveOrderCheckBox.Size = new System.Drawing.Size(81, 17);
            this.liveOrderCheckBox.TabIndex = 24;
            this.liveOrderCheckBox.Text = "Live Order :";
            this.liveOrderCheckBox.UseVisualStyleBackColor = false;
            // 
            // googleRadioBtn
            // 
            this.googleRadioBtn.AutoSize = true;
            this.googleRadioBtn.Checked = true;
            this.googleRadioBtn.Location = new System.Drawing.Point(8, 17);
            this.googleRadioBtn.Name = "googleRadioBtn";
            this.googleRadioBtn.Size = new System.Drawing.Size(100, 17);
            this.googleRadioBtn.TabIndex = 25;
            this.googleRadioBtn.TabStop = true;
            this.googleRadioBtn.Text = "Google Finance";
            this.googleRadioBtn.UseVisualStyleBackColor = true;
            // 
            // zerodhaRadioBtn
            // 
            this.zerodhaRadioBtn.AutoSize = true;
            this.zerodhaRadioBtn.Location = new System.Drawing.Point(114, 17);
            this.zerodhaRadioBtn.Name = "zerodhaRadioBtn";
            this.zerodhaRadioBtn.Size = new System.Drawing.Size(65, 17);
            this.zerodhaRadioBtn.TabIndex = 26;
            this.zerodhaRadioBtn.TabStop = true;
            this.zerodhaRadioBtn.Text = "Zerodha";
            this.zerodhaRadioBtn.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.googleRadioBtn);
            this.groupBox1.Controls.Add(this.zerodhaRadioBtn);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 40);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "API";
            // 
            // OrderSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 146);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.liveOrderCheckBox);
            this.Controls.Add(this.statusLbl);
            this.Controls.Add(this.profitTxtBox);
            this.Controls.Add(this.label1);
            this.Name = "OrderSettings";
            this.Text = "Order Settings";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox profitTxtBox;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label statusLbl;
        private System.Windows.Forms.CheckBox liveOrderCheckBox;
        private System.Windows.Forms.RadioButton googleRadioBtn;
        private System.Windows.Forms.RadioButton zerodhaRadioBtn;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}