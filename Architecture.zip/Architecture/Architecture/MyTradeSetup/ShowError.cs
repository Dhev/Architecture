﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MyTradeSetup
{
    public partial class ShowError : Form
    {
        public ShowError()
        {
            InitializeComponent();
            LoadError();
        }

        private void refreshBtn_Click(object sender, EventArgs e)
        {
            LoadError();
        }

        private void LoadError()
        {
            textBox1.Text = "";
            foreach (List<string> err in ErrorHandler.ErrorList)
            {
                foreach (string s in err)
                {
                    textBox1.Text = textBox1.Text + s + System.Environment.NewLine;
                }
                textBox1.Text = textBox1.Text + "--------------------------------------------------" + System.Environment.NewLine;
            }
        }
    }
}
