﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyTradeSetup
{
    public enum OrderType
    {
        Buy,
        Sell
    }

    public enum OrderStatus
    {
        NotExecuted,
        InProgress,
        Completed,
        TimeElapsed
    }

    public enum Strategy
    {
        TopGainner,
        PriceAction,
        ORB
    }


    public static class Orders
    {
        public static List<Order> MyOrders { get; set; }
    }

    public class Order
    {
        private OrderStatus orderStatus;
        private double profitLoss { get; set; }
        public Strategy Strategy { get; set; }
        public DateTime DateTime { get; set; }
        public string Stock { get; set; }
        public OrderType OrderType { get; set; }
        public double BuyPrice { get; set; }
        public double SellPrice { get; set; }
        public int Qty { get; set; }
        public double CurrPrice { get; set; }
        public double ProfitLoss { get { return profitLoss; } set { profitLoss = value; UpdatePLPercentage(); } }       
        public double PLPercentage { get; set; }
        public double TriggerPrice { get; set; }
        public double Target { get; set; }
        public double TargetPercentage { get; set; }
        public bool TrailingTarget { get; set; }
        public double StopLoss { get; set; }
        public double StopLossPercentage { get; set; }
        public OrderStatus OrderStatus { get { return orderStatus; } set { orderStatus = value; UpdateDetail(orderStatus); } }
        public bool TrailingSL { get; set; }
        public double TrailingSLPrice { get; set; }
        public DateTime ValidUpTo { get; set; }
        public string Detail { get; set; }
        public string MailGrpByName { get; set; }
        public string OrderId { get; set; }
        public int TopGinerLosser { get; set; }

        private void UpdatePLPercentage()
        {
            double plPercentage = 0;
            double pl = 0;
            if (this.OrderStatus == OrderStatus.Completed)
            {
                pl = this.SellPrice - this.BuyPrice;
            }
            else if (this.OrderStatus == OrderStatus.InProgress)
            {
                if (this.OrderType == OrderType.Buy) pl = this.CurrPrice - this.BuyPrice;
                else pl = this.SellPrice - this.CurrPrice;
            }
            if ((this.OrderStatus == OrderStatus.Completed) || (this.OrderStatus == OrderStatus.InProgress))
            {
                if (this.OrderType == OrderType.Buy) plPercentage = (pl / this.BuyPrice) * 100;
                else plPercentage = (pl / this.SellPrice) * 100;

                plPercentage = Math.Round(plPercentage, 2);
                this.PLPercentage = plPercentage;
            }
        }

        public void CheckOrderCompleted()
        {
            if (OrderStatus != OrderStatus.InProgress) return;

            bool orderClosed = false;
            bool marketClosed = false;
            //Close End of the market
            marketClosed = OrderSettings.CloseAllOrders;
            if (DateTime.Now >= DateTime.ParseExact(DateTime.Now.Date.ToString("yyyy-MM-dd") + " 03:27:00 PM", "yyyy-MM-dd hh:mm:ss tt", System.Globalization.CultureInfo.InvariantCulture))
            {
                marketClosed = true;
            }
            
            
            if (this.OrderType == OrderType.Buy)
            {
                if (marketClosed == true)
                {
                    CloseBuyOrder();
                    orderClosed = true;
                }
                if (this.Target == this.StopLoss)
                {
                    if (this.Target == this.CurrPrice)
                    {
                        CloseBuyOrder();
                        orderClosed = true;
                    }
                }
                else if ((this.Target <= this.CurrPrice) || (this.StopLoss >= this.CurrPrice))
                {
                    CloseBuyOrder();
                    orderClosed = true;
                }
                if (orderClosed == false)
                {
                    this.ProfitLoss = CalcProfitLoss(this.BuyPrice, this.CurrPrice, this.Qty);

                    if (this.TrailingSLPrice <= 0) this.TrailingSLPrice = this.BuyPrice;

                    if ((TrailingSL) && (this.CurrPrice > this.TrailingSLPrice))
                    {
                        double diff = this.CurrPrice - this.TrailingSLPrice;
                        if (diff >= calcPercentageOfPrice(this.CurrPrice))
                        {
                            UpdateDetail("-----------");
                            UpdateDetail("P&L-Updated");
                            UpdateDetail("Curr:" + this.CurrPrice.ToString());
                            //UpdateDetail("TrailingSL:" + this.TrailingSLPrice.ToString());
                            UpdateDetail("-----------");
                            //this.Target = this.Target + calcPercentageOfPrice(this.CurrPrice);
                            //this.StopLoss = this.StopLoss + calcPercentageOfPrice(this.CurrPrice);     

                            if (this.TrailingTarget)
                                this.Target = this.Target + diff;

                            this.StopLoss = this.StopLoss + diff;
                           
                            if (this.StopLoss > this.BuyPrice)
                            {
                                if (this.StopLoss < (this.CurrPrice - (calcPercentageOfPrice(this.CurrPrice) * 3)))
                                    this.StopLoss = (this.CurrPrice - (calcPercentageOfPrice(this.CurrPrice) * 3));
                            }                            
                            this.TrailingSLPrice = this.CurrPrice;
                            LiveOrders live = new LiveOrders();
                            live.ModifyOrder(this.OrderId, this.Qty, this.Target, this.StopLoss);
                        }
                    }
                }
            }
            else
            {
                if (marketClosed == true)
                {
                    CloseSellOrder();
                    orderClosed = true;
                }
                if (this.Target == this.StopLoss)
                {
                    if (this.Target == this.CurrPrice)
                    {
                        CloseSellOrder();
                        orderClosed = true;
                    }
                }
                else if ((this.Target >= this.CurrPrice) || (this.StopLoss <= this.CurrPrice))
                {
                    CloseSellOrder();
                    orderClosed = true;
                }
                if (orderClosed == false)
                {
                    this.ProfitLoss = CalcProfitLoss(this.CurrPrice, this.SellPrice, this.Qty);

                    if (this.TrailingSLPrice <= 0) this.TrailingSLPrice = this.SellPrice;

                    if ((TrailingSL) && (this.CurrPrice < this.TrailingSLPrice))
                    {
                        double diff = this.TrailingSLPrice - this.CurrPrice;
                        if (diff >= calcPercentageOfPrice(this.CurrPrice))
                        {
                            UpdateDetail("-----------");
                            UpdateDetail("P&L-Updated");
                            //UpdateDetail("TrailingSL:" + this.TrailingSLPrice.ToString());
                            UpdateDetail("Curr:" + this.CurrPrice.ToString());
                            UpdateDetail("-----------");
                           
                            //this.Target = this.Target - calcPercentageOfPrice(this.CurrPrice);
                            //this.StopLoss = this.StopLoss - calcPercentageOfPrice(this.CurrPrice);    

                            if (this.TrailingTarget)
                                this.Target = this.Target - diff;

                            this.StopLoss = this.StopLoss - diff;  

                            if (this.StopLoss < this.SellPrice)
                            {
                                if (this.StopLoss > (this.CurrPrice + (calcPercentageOfPrice(this.CurrPrice) * 3)))
                                    this.StopLoss = (this.CurrPrice + (calcPercentageOfPrice(this.CurrPrice) * 3));
                            }
                            this.TrailingSLPrice = this.CurrPrice;
                            LiveOrders live = new LiveOrders();
                            live.ModifyOrder(this.OrderId, this.Qty, this.Target, this.StopLoss);
                        }
                    }
                }
            }
        }

        public double calcPercentageOfPrice(double price)
        {
            return (.15 / 100) * price;
        }

        private void CloseBuyOrder()
        {
            this.SellPrice = this.CurrPrice;
            this.OrderStatus = OrderStatus.Completed;
            this.ProfitLoss = CalcProfitLoss(this.BuyPrice, this.SellPrice, this.Qty);
            LiveOrders live = new LiveOrders();
            live.ExistOrder(this.OrderId);
        }

        private void CloseSellOrder()
        {
            this.BuyPrice = this.CurrPrice;
            this.OrderStatus = OrderStatus.Completed;
            this.ProfitLoss = CalcProfitLoss(this.BuyPrice, this.SellPrice, this.Qty);
            LiveOrders live = new LiveOrders();
            live.ExistOrder(this.OrderId);
        }

        private void UpdateDetail(OrderStatus orderStatus)
        {
            this.Detail = this.Detail + DateTime.Now.ToString("hh:mmtt") + ":" + this.OrderStatus + System.Environment.NewLine;
        }

        public void UpdateDetail(string detail)
        {
            this.Detail = this.Detail + DateTime.Now.ToString("hh:mmtt") + ":" + detail + System.Environment.NewLine;
        }


        public double CalcProfitLoss(double buyP, double sellP, int qty)
        {
            double pl = ((sellP * qty) - (buyP * qty));
            return Math.Round(pl, 2);
        }


    }

}
