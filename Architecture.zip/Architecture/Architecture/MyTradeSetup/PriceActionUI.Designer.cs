﻿namespace MyTradeSetup
{
    partial class PriceActionUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.topComboBox = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.topGainerLosserCheckBox = new System.Windows.Forms.CheckBox();
            this.removeCandleCheckBox = new System.Windows.Forms.CheckBox();
            this.testConnectionBtn = new System.Windows.Forms.Button();
            this.orbCheckBox = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.trailingProfit_CheckBox = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioBtn30min = new System.Windows.Forms.RadioButton();
            this.radioBtn15min = new System.Windows.Forms.RadioButton();
            this.chechUpdatesCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stopLossTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.basedOnPreviousCandleCheckBox = new System.Windows.Forms.CheckBox();
            this.profitTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.workHoursCheckBox = new System.Windows.Forms.CheckBox();
            this.paLabel = new System.Windows.Forms.Label();
            this.trailingSL_CheckBox = new System.Windows.Forms.CheckBox();
            this.actionPercentageTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.startBtn = new System.Windows.Forms.Button();
            this.levelComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.logTextBox = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.removeCandleCheckBox);
            this.panel1.Controls.Add(this.testConnectionBtn);
            this.panel1.Controls.Add(this.orbCheckBox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.trailingProfit_CheckBox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.chechUpdatesCheckBox);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.profitTextBox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.workHoursCheckBox);
            this.panel1.Controls.Add(this.paLabel);
            this.panel1.Controls.Add(this.trailingSL_CheckBox);
            this.panel1.Controls.Add(this.actionPercentageTextBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.statusLabel);
            this.panel1.Controls.Add(this.startBtn);
            this.panel1.Controls.Add(this.levelComboBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(958, 274);
            this.panel1.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.topComboBox);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.topGainerLosserCheckBox);
            this.groupBox3.Location = new System.Drawing.Point(347, 48);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(310, 37);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            // 
            // topComboBox
            // 
            this.topComboBox.AllowDrop = true;
            this.topComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.topComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.topComboBox.FormattingEnabled = true;
            this.topComboBox.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.topComboBox.Location = new System.Drawing.Point(240, 11);
            this.topComboBox.MaxDropDownItems = 10;
            this.topComboBox.Name = "topComboBox";
            this.topComboBox.Size = new System.Drawing.Size(52, 21);
            this.topComboBox.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(197, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "Top :";
            // 
            // topGainerLosserCheckBox
            // 
            this.topGainerLosserCheckBox.AutoSize = true;
            this.topGainerLosserCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.topGainerLosserCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topGainerLosserCheckBox.Location = new System.Drawing.Point(6, 14);
            this.topGainerLosserCheckBox.Name = "topGainerLosserCheckBox";
            this.topGainerLosserCheckBox.Size = new System.Drawing.Size(175, 17);
            this.topGainerLosserCheckBox.TabIndex = 24;
            this.topGainerLosserCheckBox.Text = "Must be Top Gainer/Loser";
            this.topGainerLosserCheckBox.UseVisualStyleBackColor = true;
            this.topGainerLosserCheckBox.CheckedChanged += new System.EventHandler(this.topGainerLosserCheckBox_CheckedChanged);
            // 
            // removeCandleCheckBox
            // 
            this.removeCandleCheckBox.AutoSize = true;
            this.removeCandleCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.removeCandleCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.removeCandleCheckBox.Location = new System.Drawing.Point(10, 62);
            this.removeCandleCheckBox.Name = "removeCandleCheckBox";
            this.removeCandleCheckBox.Size = new System.Drawing.Size(328, 17);
            this.removeCandleCheckBox.TabIndex = 23;
            this.removeCandleCheckBox.Text = "Dont include candle which body is less than action %";
            this.removeCandleCheckBox.UseVisualStyleBackColor = true;
            // 
            // testConnectionBtn
            // 
            this.testConnectionBtn.Location = new System.Drawing.Point(504, 190);
            this.testConnectionBtn.Name = "testConnectionBtn";
            this.testConnectionBtn.Size = new System.Drawing.Size(104, 23);
            this.testConnectionBtn.TabIndex = 22;
            this.testConnectionBtn.Text = "Test Connection";
            this.testConnectionBtn.UseVisualStyleBackColor = true;
            this.testConnectionBtn.Click += new System.EventHandler(this.testConnectionBtn_Click);
            // 
            // orbCheckBox
            // 
            this.orbCheckBox.AutoSize = true;
            this.orbCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orbCheckBox.Location = new System.Drawing.Point(537, 25);
            this.orbCheckBox.Name = "orbCheckBox";
            this.orbCheckBox.Size = new System.Drawing.Size(52, 17);
            this.orbCheckBox.TabIndex = 21;
            this.orbCheckBox.Text = "ORB";
            this.orbCheckBox.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Stop Loss % :";
            // 
            // trailingProfit_CheckBox
            // 
            this.trailingProfit_CheckBox.AutoSize = true;
            this.trailingProfit_CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trailingProfit_CheckBox.Location = new System.Drawing.Point(191, 98);
            this.trailingProfit_CheckBox.Name = "trailingProfit_CheckBox";
            this.trailingProfit_CheckBox.Size = new System.Drawing.Size(102, 17);
            this.trailingProfit_CheckBox.TabIndex = 19;
            this.trailingProfit_CheckBox.Text = "Trailing Profit";
            this.trailingProfit_CheckBox.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Candle Intervel :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioBtn30min);
            this.groupBox2.Controls.Add(this.radioBtn15min);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(123, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(131, 45);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            // 
            // radioBtn30min
            // 
            this.radioBtn30min.AutoSize = true;
            this.radioBtn30min.Checked = true;
            this.radioBtn30min.Location = new System.Drawing.Point(6, 18);
            this.radioBtn30min.Name = "radioBtn30min";
            this.radioBtn30min.Size = new System.Drawing.Size(62, 17);
            this.radioBtn30min.TabIndex = 16;
            this.radioBtn30min.TabStop = true;
            this.radioBtn30min.Text = "30 min";
            this.radioBtn30min.UseVisualStyleBackColor = true;
            // 
            // radioBtn15min
            // 
            this.radioBtn15min.AutoSize = true;
            this.radioBtn15min.Location = new System.Drawing.Point(68, 18);
            this.radioBtn15min.Name = "radioBtn15min";
            this.radioBtn15min.Size = new System.Drawing.Size(62, 17);
            this.radioBtn15min.TabIndex = 15;
            this.radioBtn15min.Text = "15 min";
            this.radioBtn15min.UseVisualStyleBackColor = true;
            // 
            // chechUpdatesCheckBox
            // 
            this.chechUpdatesCheckBox.AutoSize = true;
            this.chechUpdatesCheckBox.Checked = true;
            this.chechUpdatesCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chechUpdatesCheckBox.Enabled = false;
            this.chechUpdatesCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chechUpdatesCheckBox.Location = new System.Drawing.Point(200, 194);
            this.chechUpdatesCheckBox.Name = "chechUpdatesCheckBox";
            this.chechUpdatesCheckBox.Size = new System.Drawing.Size(219, 17);
            this.chechUpdatesCheckBox.TabIndex = 14;
            this.chechUpdatesCheckBox.Text = "Check updates on Candle Intervel";
            this.chechUpdatesCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.stopLossTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.basedOnPreviousCandleCheckBox);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(119, 122);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 45);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // stopLossTextBox
            // 
            this.stopLossTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stopLossTextBox.Location = new System.Drawing.Point(279, 15);
            this.stopLossTextBox.Name = "stopLossTextBox";
            this.stopLossTextBox.Size = new System.Drawing.Size(54, 20);
            this.stopLossTextBox.TabIndex = 2;
            this.stopLossTextBox.Leave += new System.EventHandler(this.stopLossTextBox_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(223, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "or SL %";
            // 
            // basedOnPreviousCandleCheckBox
            // 
            this.basedOnPreviousCandleCheckBox.AutoSize = true;
            this.basedOnPreviousCandleCheckBox.Location = new System.Drawing.Point(6, 19);
            this.basedOnPreviousCandleCheckBox.Name = "basedOnPreviousCandleCheckBox";
            this.basedOnPreviousCandleCheckBox.Size = new System.Drawing.Size(207, 17);
            this.basedOnPreviousCandleCheckBox.TabIndex = 0;
            this.basedOnPreviousCandleCheckBox.Text = "Based on Previous Candle(BPC)";
            this.basedOnPreviousCandleCheckBox.UseVisualStyleBackColor = true;
            this.basedOnPreviousCandleCheckBox.CheckedChanged += new System.EventHandler(this.basedOnPreviousCandleCheckBox_CheckedChanged);
            // 
            // profitTextBox
            // 
            this.profitTextBox.Location = new System.Drawing.Point(119, 96);
            this.profitTextBox.Name = "profitTextBox";
            this.profitTextBox.Size = new System.Drawing.Size(53, 20);
            this.profitTextBox.TabIndex = 12;
            this.profitTextBox.Leave += new System.EventHandler(this.profitTextBox_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(55, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Profit % :";
            // 
            // workHoursCheckBox
            // 
            this.workHoursCheckBox.AutoSize = true;
            this.workHoursCheckBox.Checked = true;
            this.workHoursCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.workHoursCheckBox.Enabled = false;
            this.workHoursCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.workHoursCheckBox.Location = new System.Drawing.Point(19, 195);
            this.workHoursCheckBox.Name = "workHoursCheckBox";
            this.workHoursCheckBox.Size = new System.Drawing.Size(175, 17);
            this.workHoursCheckBox.TabIndex = 10;
            this.workHoursCheckBox.Text = "Works 9:40AM to 3:30 PM";
            this.workHoursCheckBox.UseVisualStyleBackColor = true;
            // 
            // paLabel
            // 
            this.paLabel.AutoSize = true;
            this.paLabel.Location = new System.Drawing.Point(12, 224);
            this.paLabel.Name = "paLabel";
            this.paLabel.Size = new System.Drawing.Size(27, 13);
            this.paLabel.TabIndex = 5;
            this.paLabel.Text = "PA..";
            // 
            // trailingSL_CheckBox
            // 
            this.trailingSL_CheckBox.AutoSize = true;
            this.trailingSL_CheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trailingSL_CheckBox.Location = new System.Drawing.Point(480, 141);
            this.trailingSL_CheckBox.Name = "trailingSL_CheckBox";
            this.trailingSL_CheckBox.Size = new System.Drawing.Size(128, 17);
            this.trailingSL_CheckBox.TabIndex = 7;
            this.trailingSL_CheckBox.Text = "Trailing Stop Loss";
            this.trailingSL_CheckBox.UseVisualStyleBackColor = true;
            // 
            // actionPercentageTextBox
            // 
            this.actionPercentageTextBox.Location = new System.Drawing.Point(477, 22);
            this.actionPercentageTextBox.Name = "actionPercentageTextBox";
            this.actionPercentageTextBox.Size = new System.Drawing.Size(46, 20);
            this.actionPercentageTextBox.TabIndex = 6;
            this.actionPercentageTextBox.Leave += new System.EventHandler(this.actionPercentageTextBox_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(407, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Action % :";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Location = new System.Drawing.Point(614, 196);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(43, 13);
            this.statusLabel.TabIndex = 4;
            this.statusLabel.Text = "Status..";
            // 
            // startBtn
            // 
            this.startBtn.Location = new System.Drawing.Point(425, 190);
            this.startBtn.Name = "startBtn";
            this.startBtn.Size = new System.Drawing.Size(73, 23);
            this.startBtn.TabIndex = 2;
            this.startBtn.Text = "Start";
            this.startBtn.UseVisualStyleBackColor = true;
            this.startBtn.Click += new System.EventHandler(this.startBtn_Click);
            // 
            // levelComboBox
            // 
            this.levelComboBox.AllowDrop = true;
            this.levelComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.levelComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.levelComboBox.FormattingEnabled = true;
            this.levelComboBox.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.levelComboBox.Location = new System.Drawing.Point(347, 22);
            this.levelComboBox.MaxDropDownItems = 10;
            this.levelComboBox.Name = "levelComboBox";
            this.levelComboBox.Size = new System.Drawing.Size(52, 21);
            this.levelComboBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(260, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "No of Level :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.logTextBox);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 274);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(958, 198);
            this.panel2.TabIndex = 1;
            // 
            // logTextBox
            // 
            this.logTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logTextBox.Location = new System.Drawing.Point(0, 0);
            this.logTextBox.Multiline = true;
            this.logTextBox.Name = "logTextBox";
            this.logTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.logTextBox.Size = new System.Drawing.Size(958, 198);
            this.logTextBox.TabIndex = 6;
            // 
            // PriceActionUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 472);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "PriceActionUI";
            this.Text = "Price Action";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PriceActionUI_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox levelComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button startBtn;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label paLabel;
        private System.Windows.Forms.TextBox actionPercentageTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox trailingSL_CheckBox;
        private System.Windows.Forms.TextBox logTextBox;
        private System.Windows.Forms.CheckBox workHoursCheckBox;
        private System.Windows.Forms.TextBox profitTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox stopLossTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox basedOnPreviousCandleCheckBox;
        private System.Windows.Forms.CheckBox chechUpdatesCheckBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioBtn30min;
        private System.Windows.Forms.RadioButton radioBtn15min;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox trailingProfit_CheckBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox orbCheckBox;
        private System.Windows.Forms.Button testConnectionBtn;
        private System.Windows.Forms.CheckBox removeCandleCheckBox;
        private System.Windows.Forms.ComboBox topComboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox topGainerLosserCheckBox;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}