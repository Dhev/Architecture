﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using System.Timers;

namespace GoogleFinance
{
    public class StockPrice : IStockPrice
    {
        public event Error_EventHandler ErrorRised;
        public static Dictionary<string, double> stockDic = new Dictionary<string, double>();
        System.Windows.Forms.Timer timer1 ;
        System.Windows.Forms.WebBrowser webBrowser1;
        public StockPrice()
        {
            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 1000;
            timer1.Tick += new EventHandler(timer1_Tick);
            timer1.Enabled = true;
            timer1.Start();
            
            webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.TabIndex = 1;
            this.webBrowser1.Visible = false;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(webBrowser1_DocumentCompleted);
        }

        private void AddStock(string stock)
        {
            if (stockDic.ContainsKey(stock) == false)
            {
                stockDic[stock] = 0;
            }
        }

        public double GetPrice(string stock)
        {
            if (stockDic.ContainsKey(stock))
            {
                return stockDic[stock];
            }
            else
            {
                AddStock(stock);
                return 0;
            }
            
        }

        void timer1_Tick(object sender, EventArgs e)
        {
            string updatePrice = "";
            foreach(string stock in stockDic.Keys)
            {
                if (updatePrice.Contains("NSE:" + stock + ",") == false)
                    updatePrice += "NSE:" + stock + ",";
            }
            if (String.IsNullOrEmpty(updatePrice) == false)
            {
                timer1.Stop();
                string url = ("http://finance.google.com/finance/info?client=ig&q=" + updatePrice);
                webBrowser1.Navigate(url);
            }
        }

        void webBrowser1_DocumentCompleted(object sender, System.Windows.Forms.WebBrowserDocumentCompletedEventArgs e)
        {
             string data = "";
             try
             {
                 data = webBrowser1.Document.Body.InnerText;

                 data = data.Replace("\"", "");
                 data = data.Replace("// [ ", "");
                 data = data.Replace(" ] ", "");
                 string[] stocksData = data.Split(new char[] { '}' }, StringSplitOptions.RemoveEmptyEntries);

                 for (int i = 0; i < stocksData.Count(); i++)
                 {
                     int startInd = stocksData[i].IndexOf("l_fix : ");
                     int endInd = stocksData[i].IndexOf(",", startInd);

                     string data1 = stocksData[i].Substring(startInd, (endInd - startInd));
                     string pri = data1.Replace("l_fix : ", "").Replace(" ", "");

                     startInd = stocksData[i].IndexOf("t : ");
                     endInd = stocksData[i].IndexOf(",", startInd);

                     data1 = stocksData[i].Substring(startInd, (endInd - startInd));
                     string stock = data1.Replace("t : ", "").Replace(" ", "");
                     stock = stock.Replace("M\u0026M", "M%26M");

                     stockDic[stock] = Convert.ToDouble(pri);
                 }
             }
             catch (Exception exception)
             {
                 ErrorRised(exception);
             }
             finally
             {
                 timer1.Start();
             }
        }
    }
}
