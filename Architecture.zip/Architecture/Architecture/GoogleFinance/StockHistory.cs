﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using System.Timers;
using System.Data;

namespace GoogleFinance
{
    public class StockHistory : IStockHistory
    {
        public event HistoryUpdated_EventHandler HistoryUpdated;
        public event Error_EventHandler ErrorRised;
        public static Dictionary<string, DataTable> stockDic15mins = new Dictionary<string, DataTable>();
        static System.Timers.Timer historyTimer;
        static System.Windows.Forms.WebBrowser webBrowser1;
        static bool workOnlyInTradingHours;
        static bool workOnlyInInterval;
        static int stockRunningCount;
        static List<string> nifty50;
        public StockHistory(List<string> nifty)
        {
            nifty50 = nifty;
            workOnlyInTradingHours = true;
            workOnlyInInterval = true;
            historyTimer = new System.Timers.Timer();
            historyTimer.Interval = 1000;
            //historyTimer.Tick += new EventHandler(historyTimer_Tick);
            historyTimer.Elapsed += new ElapsedEventHandler(historyTimer_Elapsed);
            historyTimer.Enabled = true;
            historyTimer.Start();

            webBrowser1 = new System.Windows.Forms.WebBrowser();
            webBrowser1.Name = "webBrowser1";
            webBrowser1.TabIndex = 1;
            webBrowser1.Visible = false;
            webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(webBrowser1_DocumentCompleted);
        }

        
        public DataTable TestConnection(string stock)
        {
            if (stockDic15mins.ContainsKey(stock))
            {
                return stockDic15mins[stock];
            }
            else
            {
                historyTimer.Stop();
                string url = @"https://www.google.com/finance/getprices?q=" + stock + "&x=NSE&i=901&p=1d&f=d,o,h,l,c,v";
                webBrowser1.Navigate(url);
                return null;
            }
        }

        //void historyTimer_Tick(object sender, EventArgs e)
        void historyTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (workOnlyInTradingHours)
            {
                DateTime startTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 9, 40, 0, 0);
                DateTime endTime = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 15, 31, 0, 0);
                if ((startTime <= DateTime.Now) && DateTime.Now <= endTime)
                {
                    if (workOnlyInInterval)
                    {
                        if (CheckUpdates())
                            LoadURL();
                    }
                    else
                        LoadURL();

                }
            }
            else
            {
                if (workOnlyInInterval)
                {
                    if (CheckUpdates())
                        LoadURL();
                }
                else
                    LoadURL();
            }
        }

        void LoadURL()
        {
            if (stockRunningCount >= nifty50.Count)
            {
                stockRunningCount = 0;
            }
            historyTimer.Stop();
            string url = @"https://www.google.com/finance/getprices?q=" + nifty50[stockRunningCount] + "&x=NSE&i=901&p=1d&f=d,o,h,l,c,v";
            webBrowser1.Navigate(url);
        }



        void webBrowser1_DocumentCompleted(object sender, System.Windows.Forms.WebBrowserDocumentCompletedEventArgs e)
        {
            string dataStr = "";
            try
            {
                dataStr = webBrowser1.Document.GetElementsByTagName("pre")[0].InnerText;

                string stock = webBrowser1.Url.ToString();
                stock = stock.Substring(stock.IndexOf("q=") + 2);
                stock = stock.Substring(0, stock.IndexOf("x=") - 1);
                stock = stock.Replace("&", "%26");

                string[] dataLine = dataStr.Split(new string[] { Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
                string columns = dataLine[4];
                columns = columns.Replace("COLUMNS=", "");
                double UnixTimeStamp = 0;

                if (stockDic15mins.ContainsKey(stock)==false)
                {
                    stockDic15mins[stock] = new DataTable();
                    //Loading Header Start
                    foreach (string col in columns.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        switch (col)
                        {
                            case "DATE":
                                stockDic15mins[stock].Columns.Add(new DataColumn("datetime", typeof(DateTime)));
                                break;
                            case "OPEN":
                                stockDic15mins[stock].Columns.Add(new DataColumn("open", typeof(decimal)));
                                break;
                            case "CLOSE":
                                stockDic15mins[stock].Columns.Add(new DataColumn("close", typeof(decimal)));
                                break;
                            case "HIGH":
                                stockDic15mins[stock].Columns.Add(new DataColumn("high", typeof(decimal)));
                                break;
                            case "LOW":
                                stockDic15mins[stock].Columns.Add(new DataColumn("low", typeof(decimal)));
                                break;
                            case "VOLUME":
                                stockDic15mins[stock].Columns.Add(new DataColumn("volume", typeof(int)));
                                break;
                        }
                    }
                }
                else
                    stockDic15mins[stock].Rows.Clear();
                //Loading Header End

                //Loading Value Start
                for (int i = 7; i < dataLine.Count(); i++)
                {
                    string[] colData = dataLine[i].Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
                    DateTime dt;

                    if (colData[0].StartsWith("a"))
                    {
                        UnixTimeStamp = Convert.ToDouble(colData[0].Replace("a", ""));
                        dt = UnixTimeStampToDateTime(UnixTimeStamp);
                    }
                    else
                    {
                        dt = UnixTimeStampToDateTime(UnixTimeStamp + (Convert.ToInt32(colData[0]) * 900));
                    }
                    DataRow dr = stockDic15mins[stock].NewRow();
                    dr[0] = dt;
                    int coli = 0;
                    foreach (string col in columns.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        if (coli == 0)
                        {
                            coli++;
                            continue;
                        }

                        dr[coli] = Convert.ChangeType(colData[coli], stockDic15mins[stock].Columns[coli].DataType);
                        coli++;
                    }
                    if (dt <= DateTime.Now)
                        stockDic15mins[stock].Rows.Add(dr);
                }

                stockDic15mins[stock] = RemoveYesterdayRows(stock, stockDic15mins[stock]);
                stockDic15mins[stock] = RemovePreMarketRow(stockDic15mins[stock]);

                stockRunningCount = stockRunningCount + 1;
                DataTable stockDic30mins = Convert30minDT(stockDic15mins[stock]);
                HistoryUpdated(stock, stockDic15mins[stock], stockDic30mins);
            }
            catch (Exception exception)
            {
                ErrorRised(exception);
            }
            finally
            {
                historyTimer.Start();
            }
        }

        public static DateTime UnixTimeStampToDateTime(double unixTimeStamp)
        {
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToLocalTime();

            return dtDateTime;
        }

        private DataTable RemoveYesterdayRows(string stock, DataTable dataDT)
        {
            List<DataRow> rowsToDelete = new List<DataRow>();
            bool hasOldData = false;
            for (int i = 0; i < dataDT.Rows.Count; i++)
            {
                DateTime dt = Convert.ToDateTime(dataDT.Rows[i]["datetime"]);
                //DateTime dt = DateTime.ParseExact(ss, "dd-MM-yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                if (dt.ToString("dd-MM-yyyy") != DateTime.Now.ToString("dd-MM-yyyy"))
                {
                    rowsToDelete.Add(dataDT.Rows[i]);
                    hasOldData = true;
                }
            }
            //if (hasOldData)
            //    logTextBox.AppendText(DateTime.Now.ToString("d/M/yy hh:mm:ss tt") + ": Stock " + stock + " has old data." + System.Environment.NewLine);

            foreach (DataRow row in rowsToDelete)
            {
                dataDT.Rows.Remove(row);
            }

            return dataDT;
        }

        private DataTable RemovePreMarketRow(DataTable dataDT)
        {
            if (dataDT != null && dataDT.Rows.Count > 0)
            {
                DateTime dt = Convert.ToDateTime(dataDT.Rows[0]["datetime"]);
                //DateTime dt = DateTime.ParseExact(ss, "dd-MM-yyyy hh:mm:ss tt", CultureInfo.InvariantCulture);
                if ((dt.Hour == 9) && (dt.Minute == 15))
                {
                    dataDT.Rows.RemoveAt(0);
                }
            }
            return dataDT;
        }

        private DataTable Convert30minDT(DataTable data15minsDT)
        {
            DataTable data30min = new DataTable();
            data30min.Columns.Add(new DataColumn("datetime", typeof(DateTime)));
            data30min.Columns.Add(new DataColumn("open", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("close", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("high", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("low", typeof(decimal)));
            data30min.Columns.Add(new DataColumn("volume", typeof(int)));

            if (data15minsDT != null)
            {
                if (data15minsDT.Rows.Count >= 2)
                {
                    int count = data15minsDT.Rows.Count;
                    if ((count % 2) != 0)
                        count = count - 1;

                    for (int i = 0; i < count; i = i + 2)
                    {
                        StockPrice sp1;
                        StockPrice sp2;
                        GetRowData(data15minsDT, i, i + 1, out sp1, out sp2);

                        DataRow dr = data30min.NewRow();
                        dr["datetime"] = data15minsDT.Rows[i + 1]["datetime"];
                        dr["open"] = sp1.Open;
                        dr["close"] = sp2.Close;

                        if (sp1.High > sp2.High)
                            dr["high"] = sp1.High;
                        else
                            dr["high"] = sp2.High;

                        if (sp1.Low < sp2.Low)
                            dr["low"] = sp1.Low;
                        else
                            dr["low"] = sp2.Low;

                        dr["volume"] = Convert.ToInt32(data15minsDT.Rows[i]["volume"]) + Convert.ToInt32(data15minsDT.Rows[i + 1]["volume"]);

                        data30min.Rows.Add(dr);
                    }
                }
            }

            return data30min;
        }

        public void GetRowData(DataTable dataDT, int rowNo1, int rowNo2, out StockPrice sp1, out StockPrice sp2) //move this method to util
        {
            sp1 = new StockPrice();
            sp1.Open = Convert.ToDouble(dataDT.Rows[rowNo1]["open"]);
            sp1.Close = Convert.ToDouble(dataDT.Rows[rowNo1]["close"]);
            sp1.High = Convert.ToDouble(dataDT.Rows[rowNo1]["high"]);
            sp1.Low = Convert.ToDouble(dataDT.Rows[rowNo1]["low"]);

            sp2 = new StockPrice();
            sp2.Open = Convert.ToDouble(dataDT.Rows[rowNo2]["open"]);
            sp2.Close = Convert.ToDouble(dataDT.Rows[rowNo2]["close"]);
            sp2.High = Convert.ToDouble(dataDT.Rows[rowNo2]["high"]);
            sp2.Low = Convert.ToDouble(dataDT.Rows[rowNo2]["low"]);

        }

        public class StockPrice
        {
            public double Open { get; set; }
            public double Close { get; set; }
            public double High { get; set; }
            public double Low { get; set; }
        }

        private bool CheckUpdates()
        {
            int min = DateTime.Now.Minute;
            int sec = DateTime.Now.Second;

            if ((min == 15) && (sec >= 15)) return true;
            if ((min >= 16) && (min <= 18)) return true;

            if ((min == 30) && (sec >= 15)) return true;
            if ((min >= 31) && (min <= 33)) return true;

            if ((min == 45) && (sec >= 15)) return true;
            if ((min >= 46) && (min <= 48)) return true;

            if ((min == 0) && (sec >= 15)) return true;
            if ((min >= 1) && (min <= 3)) return true;
            
           
            stockRunningCount = 0;
            HistoryUpdated("", null, null);
            return false;
        }

        
    }
}
