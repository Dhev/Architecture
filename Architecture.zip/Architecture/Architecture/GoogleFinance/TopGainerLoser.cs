﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Common;
using System.Data;

namespace GoogleFinance
{
    public class TopGainerLoser : ITopGainerLoser
    {
        static int noOfTopGrainers;
        static bool ProcessLosers;
        public static Dictionary<string, string> dict = new Dictionary<string, string>();
        static System.Windows.Forms.Timer intervelTimer;
        static System.Windows.Forms.Timer nseTimer;
        static System.Windows.Forms.WebBrowser webBrowser2;
        public event Error_EventHandler ErrorRised;
        public TopGainerLoser()
        {
            noOfTopGrainers = 10;
            ProcessLosers = false;

            intervelTimer = new Timer();
            intervelTimer.Interval = 1000;
            intervelTimer.Tick += new EventHandler(intervelTimer_Tick);
            intervelTimer.Enabled = true;
            intervelTimer.Start();

            nseTimer = new Timer();
            nseTimer.Interval = 1000;
            nseTimer.Tick += new EventHandler(nseTimer_Tick);
            nseTimer.Enabled = true;
            nseTimer.Stop();

            webBrowser2 = new System.Windows.Forms.WebBrowser();
            webBrowser2.Name = "webBrowser2";
            webBrowser2.Visible = false;
            webBrowser2.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(webBrowser2_DocumentCompleted);
        }

        public int IsTopGainer(string stock)
        {
            foreach (var item in dict)
            {
                if (item.Key.StartsWith("TopGainer"))
                {
                    if (item.Value == stock)
                    {
                        string top = item.Key.Replace("TopGainer", "");
                        return Convert.ToInt32(top);
                    }
                }
            }
            return 0;
        }

        public int IsTopLoser(string stock)
        {
            foreach (var item in dict)
            {
                if (item.Key.StartsWith("TopLoser"))
                {
                    if (item.Value == stock)
                    {
                        string top = item.Key.Replace("TopLoser", "");
                        return Convert.ToInt32(top);
                    }
                }
            }
            return 0;
        }

        void intervelTimer_Tick(object sender, EventArgs e)
        {
            intervelTimer.Interval = 60000;
            StartProcess();           
        }

        private void StartProcess()
        {
            LoadURL();            
        }

        private void LoadURL()
        {
            intervelTimer.Stop();
            try
            {
                if (ProcessLosers == false)
                {
                    webBrowser2.Navigate("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm");
                    ProcessLosers = true;
                }
                else
                {
                    webBrowser2.Navigate("https://www.nseindia.com/live_market/dynaContent/live_analysis/top_gainers_losers.htm");
                    ProcessLosers = false;
                }
            }
            catch (Exception ex)
            {
                ErrorRised(ex);
            }
        }

        void webBrowser2_DocumentCompleted(object sender, System.Windows.Forms.WebBrowserDocumentCompletedEventArgs e)
        {
            nseTimer.Start();
        }

        void nseTimer_Tick(object sender, EventArgs e)
        {
            nseTimer.Stop();
            GetTopperFromNSE();
        }

        private void GetTopperFromNSE()
        {

            try
            {
                HtmlElement tableElement;
                if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                {
                    tableElement = webBrowser2.Document.GetElementById("topLosers");
                }
                else
                {
                    tableElement = webBrowser2.Document.GetElementById("topGainers");
                }
                var tbodyElement = tableElement.Children[0];
                for (int i = 2; i < noOfTopGrainers + 2; i++)
                {

                    var trElement = tbodyElement.Children[i];
                    string stock = trElement.Children[0].InnerText.ToUpper().Trim();
                    if (stock == "-")
                    {
                        if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                        {
                            webBrowser2.Document.GetElementById("tab8").InvokeMember("click");
                        }
                        nseTimer.Start();
                        return;
                    }
                    double price = Convert.ToDouble(trElement.Children[1].InnerText.Replace(",", ""));
                    double percentage = Convert.ToDouble(trElement.Children[2].InnerText);
                    double high = Convert.ToDouble(trElement.Children[6].InnerText.Replace(",", ""));
                    double low = Convert.ToDouble(trElement.Children[7].InnerText.Replace(",", ""));

                    if (ProcessLosers == false) // means Processing Losers. Because 'ProcessLosers' valiable get set false imediatly after the navigation.
                    {
                        string key = "TopLoser"+(i-1).ToString();
                        dict[key] = stock;
                    }
                    else
                    {
                        string key = "TopGainer" + (i - 1).ToString();
                        dict[key] = stock;
                    }

                }
                if (ProcessLosers)
                {
                    intervelTimer.Interval = 1000;
                }

                intervelTimer.Start();

            }
            catch (Exception exception)
            {
                ErrorRised(exception);
            }
        }

        private bool CheckUpdates()
        {
            int min = DateTime.Now.Minute;
            int sec = DateTime.Now.Second;

            if ((min == 15) && (sec >= 00)) return true;
            if ((min >= 16) && (min <= 18)) return true;

            if ((min == 30) && (sec >= 00)) return true;
            if ((min >= 31) && (min <= 33)) return true;

            if ((min == 45) && (sec >= 00)) return true;
            if ((min >= 46) && (min <= 48)) return true;

            if ((min == 0) && (sec >= 00)) return true;
            if ((min >= 1) && (min <= 3)) return true;

            return false;
        }


   }
}
