﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Common
{
    public delegate void HistoryUpdated_EventHandler(string stock,DataTable History15minsDT, DataTable History30minsDT);
    public delegate void Error_EventHandler(Exception exception);
    public interface IStockHistory
    {
        event HistoryUpdated_EventHandler HistoryUpdated;
        event Error_EventHandler ErrorRised;
        //DataTable GetHistory(string stock, int interval);
        DataTable TestConnection(string stock);
    }
}
