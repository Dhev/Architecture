﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public interface ITopGainerLoser
    {
        event Error_EventHandler ErrorRised;
        int IsTopGainer(string stock);
        int IsTopLoser(string stock);
    }
}
