﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common
{
    public interface IOrder
    {
        event Error_EventHandler ErrorRised;
        string PlaceOrder(string stock, string ordertype, int qty, double price, double target, double stoploss);
        void ModifyOrder(string parentid, int qty, double target, double stoploss);
        void ExistOrder(string parentid);
    }
}
