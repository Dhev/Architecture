﻿namespace Zerodha
{
    partial class ZerodhaLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnDownloadInstruments = new System.Windows.Forms.Button();
            this.BtnAccessTokenStatus = new System.Windows.Forms.Button();
            this.BtnGetAccessToken = new System.Windows.Forms.Button();
            this.BtnLogoutStatus = new System.Windows.Forms.Button();
            this.BtnLoginStatus = new System.Windows.Forms.Button();
            this.BtnInstrumentDownloadStatus = new System.Windows.Forms.Button();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.TxtAPISecret = new System.Windows.Forms.TextBox();
            this.TxtAPIKey = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.BtnUnsubscribe = new System.Windows.Forms.Button();
            this.TxtScript = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.TxtExchange = new System.Windows.Forms.TextBox();
            this.BtnSubscribe = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnDownloadInstruments
            // 
            this.BtnDownloadInstruments.Location = new System.Drawing.Point(87, 219);
            this.BtnDownloadInstruments.Name = "BtnDownloadInstruments";
            this.BtnDownloadInstruments.Size = new System.Drawing.Size(161, 23);
            this.BtnDownloadInstruments.TabIndex = 44;
            this.BtnDownloadInstruments.Text = "Download Instruments";
            this.BtnDownloadInstruments.UseVisualStyleBackColor = true;
            this.BtnDownloadInstruments.Click += new System.EventHandler(this.BtnDownloadInstruments_Click);
            // 
            // BtnAccessTokenStatus
            // 
            this.BtnAccessTokenStatus.Location = new System.Drawing.Point(87, 192);
            this.BtnAccessTokenStatus.Name = "BtnAccessTokenStatus";
            this.BtnAccessTokenStatus.Size = new System.Drawing.Size(161, 23);
            this.BtnAccessTokenStatus.TabIndex = 43;
            this.BtnAccessTokenStatus.Text = "Access Token Status";
            this.BtnAccessTokenStatus.UseVisualStyleBackColor = true;
            this.BtnAccessTokenStatus.Click += new System.EventHandler(this.BtnAccessTokenStatus_Click);
            // 
            // BtnGetAccessToken
            // 
            this.BtnGetAccessToken.Location = new System.Drawing.Point(87, 164);
            this.BtnGetAccessToken.Name = "BtnGetAccessToken";
            this.BtnGetAccessToken.Size = new System.Drawing.Size(161, 23);
            this.BtnGetAccessToken.TabIndex = 42;
            this.BtnGetAccessToken.Text = "Get Access Token";
            this.BtnGetAccessToken.UseVisualStyleBackColor = true;
            this.BtnGetAccessToken.Click += new System.EventHandler(this.BtnGetAccessToken_Click);
            // 
            // BtnLogoutStatus
            // 
            this.BtnLogoutStatus.Location = new System.Drawing.Point(87, 135);
            this.BtnLogoutStatus.Name = "BtnLogoutStatus";
            this.BtnLogoutStatus.Size = new System.Drawing.Size(161, 23);
            this.BtnLogoutStatus.TabIndex = 41;
            this.BtnLogoutStatus.Text = "Logout Status";
            this.BtnLogoutStatus.UseVisualStyleBackColor = true;
            this.BtnLogoutStatus.Click += new System.EventHandler(this.BtnLogoutStatus_Click);
            // 
            // BtnLoginStatus
            // 
            this.BtnLoginStatus.Location = new System.Drawing.Point(87, 106);
            this.BtnLoginStatus.Name = "BtnLoginStatus";
            this.BtnLoginStatus.Size = new System.Drawing.Size(161, 23);
            this.BtnLoginStatus.TabIndex = 40;
            this.BtnLoginStatus.Text = "Login Status";
            this.BtnLoginStatus.UseVisualStyleBackColor = true;
            this.BtnLoginStatus.Click += new System.EventHandler(this.BtnLoginStatus_Click);
            // 
            // BtnInstrumentDownloadStatus
            // 
            this.BtnInstrumentDownloadStatus.Location = new System.Drawing.Point(87, 248);
            this.BtnInstrumentDownloadStatus.Name = "BtnInstrumentDownloadStatus";
            this.BtnInstrumentDownloadStatus.Size = new System.Drawing.Size(161, 35);
            this.BtnInstrumentDownloadStatus.TabIndex = 39;
            this.BtnInstrumentDownloadStatus.Text = "Instrument Download Status";
            this.BtnInstrumentDownloadStatus.UseVisualStyleBackColor = true;
            this.BtnInstrumentDownloadStatus.Click += new System.EventHandler(this.BtnInstrumentDownloadStatus_Click);
            // 
            // BtnLogout
            // 
            this.BtnLogout.Location = new System.Drawing.Point(173, 77);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(75, 23);
            this.BtnLogout.TabIndex = 38;
            this.BtnLogout.Text = "Logout";
            this.BtnLogout.UseVisualStyleBackColor = true;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // BtnLogin
            // 
            this.BtnLogin.Location = new System.Drawing.Point(87, 77);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(75, 23);
            this.BtnLogin.TabIndex = 37;
            this.BtnLogin.Text = "Login";
            this.BtnLogin.UseVisualStyleBackColor = true;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // TxtAPISecret
            // 
            this.TxtAPISecret.Location = new System.Drawing.Point(87, 49);
            this.TxtAPISecret.Name = "TxtAPISecret";
            this.TxtAPISecret.Size = new System.Drawing.Size(161, 20);
            this.TxtAPISecret.TabIndex = 36;
            this.TxtAPISecret.UseSystemPasswordChar = true;
            // 
            // TxtAPIKey
            // 
            this.TxtAPIKey.Location = new System.Drawing.Point(87, 21);
            this.TxtAPIKey.Name = "TxtAPIKey";
            this.TxtAPIKey.Size = new System.Drawing.Size(161, 20);
            this.TxtAPIKey.TabIndex = 35;
            this.TxtAPIKey.UseSystemPasswordChar = true;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(23, 52);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(56, 13);
            this.Label3.TabIndex = 34;
            this.Label3.Text = "Api Secret";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(26, 26);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(43, 13);
            this.Label2.TabIndex = 33;
            this.Label2.Text = "Api Key";
            // 
            // BtnUnsubscribe
            // 
            this.BtnUnsubscribe.Location = new System.Drawing.Point(108, 375);
            this.BtnUnsubscribe.Name = "BtnUnsubscribe";
            this.BtnUnsubscribe.Size = new System.Drawing.Size(122, 23);
            this.BtnUnsubscribe.TabIndex = 50;
            this.BtnUnsubscribe.Text = "UnSubscribe Quotes";
            this.BtnUnsubscribe.UseVisualStyleBackColor = true;
            this.BtnUnsubscribe.Click += new System.EventHandler(this.BtnUnsubscribe_Click);
            // 
            // TxtScript
            // 
            this.TxtScript.Location = new System.Drawing.Point(103, 318);
            this.TxtScript.Name = "TxtScript";
            this.TxtScript.Size = new System.Drawing.Size(134, 20);
            this.TxtScript.TabIndex = 49;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(48, 321);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(43, 13);
            this.Label5.TabIndex = 48;
            this.Label5.Text = "TrdSym";
            // 
            // TxtExchange
            // 
            this.TxtExchange.Location = new System.Drawing.Point(103, 290);
            this.TxtExchange.Name = "TxtExchange";
            this.TxtExchange.Size = new System.Drawing.Size(134, 20);
            this.TxtExchange.TabIndex = 47;
            // 
            // BtnSubscribe
            // 
            this.BtnSubscribe.Location = new System.Drawing.Point(108, 346);
            this.BtnSubscribe.Name = "BtnSubscribe";
            this.BtnSubscribe.Size = new System.Drawing.Size(122, 23);
            this.BtnSubscribe.TabIndex = 46;
            this.BtnSubscribe.Text = "Subscribe Quotes";
            this.BtnSubscribe.UseVisualStyleBackColor = true;
            this.BtnSubscribe.Click += new System.EventHandler(this.BtnSubscribe_Click);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(48, 295);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(31, 13);
            this.Label4.TabIndex = 45;
            this.Label4.Text = "Exch";
            // 
            // ZerodhaLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 437);
            this.Controls.Add(this.BtnUnsubscribe);
            this.Controls.Add(this.TxtScript);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.TxtExchange);
            this.Controls.Add(this.BtnSubscribe);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.BtnDownloadInstruments);
            this.Controls.Add(this.BtnAccessTokenStatus);
            this.Controls.Add(this.BtnGetAccessToken);
            this.Controls.Add(this.BtnLogoutStatus);
            this.Controls.Add(this.BtnLoginStatus);
            this.Controls.Add(this.BtnInstrumentDownloadStatus);
            this.Controls.Add(this.BtnLogout);
            this.Controls.Add(this.BtnLogin);
            this.Controls.Add(this.TxtAPISecret);
            this.Controls.Add(this.TxtAPIKey);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Name = "ZerodhaLogin";
            this.Text = "Zerodha Login";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BtnDownloadInstruments;
        internal System.Windows.Forms.Button BtnAccessTokenStatus;
        internal System.Windows.Forms.Button BtnGetAccessToken;
        internal System.Windows.Forms.Button BtnLogoutStatus;
        internal System.Windows.Forms.Button BtnLoginStatus;
        internal System.Windows.Forms.Button BtnInstrumentDownloadStatus;
        internal System.Windows.Forms.Button BtnLogout;
        internal System.Windows.Forms.Button BtnLogin;
        internal System.Windows.Forms.TextBox TxtAPISecret;
        internal System.Windows.Forms.TextBox TxtAPIKey;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BtnUnsubscribe;
        internal System.Windows.Forms.TextBox TxtScript;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox TxtExchange;
        internal System.Windows.Forms.Button BtnSubscribe;
        internal System.Windows.Forms.Label Label4;
    }
}