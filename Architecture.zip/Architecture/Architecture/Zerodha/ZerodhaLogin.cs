﻿using System.Windows.Forms;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using KiteDotNet;
using System.IO;
using System.Globalization;

namespace Zerodha
{
    public partial class ZerodhaLogin : Form
    {
        public static Kite Kite;
      //  Dictionary<string, Double> Stocklist = new Dictionary<string, Double>();
        public ZerodhaLogin()
        {
            InitializeComponent();
            Kite = new Kite();
        }

        private void Menu_Load(object sender, System.EventArgs e)
        {
            Kite.QuotesReceivedEvent += Quotes_Received;
        }
        public void Quotes_Received(object sender, KiteDotNet.QuotesReceivedEventArgs e)
        {
            try
            {
           //  Stocklist.Add(e.TrdSym, e.Ltp);
             //MessageBox.Show(e.TrdSym + " " + e.Ltp + " " + e.Ltq);
            

            }
            catch (Exception ex)
            {
            }
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TxtAPIKey.Text))
            {
                MessageBox.Show("Please Enter Api Key");
                return;
            }

            if (string.IsNullOrEmpty(TxtAPISecret.Text))
            {
                MessageBox.Show("Please Enter Api Secret");
                return;
            }


            Kite.Api_Key = TxtAPIKey.Text;

            Kite.Api_Secret = TxtAPISecret.Text;

            Kite.Stream_Mode = Mode.Full;

            try
            {
                Kite.Login();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            try
            {
                Kite.Logout();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnLoginStatus_Click(object sender, EventArgs e)
        {
            if (Kite.Login_Status)
            {
                MessageBox.Show("Logged-In");
            }
            else
            {
                MessageBox.Show("Not Logged-In");
            }
        }

        private void BtnLogoutStatus_Click(object sender, EventArgs e)
        {
            if (Kite.Logout_Status)
            {
                MessageBox.Show("Logged-Out");
            }
            else
            {
                MessageBox.Show("Not Logged-Out");
            }
        }

        private void BtnGetAccessToken_Click(object sender, EventArgs e)
        {
            try
            {
                Kite.GetAccessToken();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAccessTokenStatus_Click(object sender, EventArgs e)
        {
            if (Kite.Access_Token_Status)
            {
                MessageBox.Show("Access Token Received");
            }
            else
            {
                MessageBox.Show("Access Token not Received");
            }
        }

        private void BtnDownloadInstruments_Click(object sender, EventArgs e)
        {
            try
            {
                Kite.GetInstruments();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnInstrumentDownloadStatus_Click(object sender, EventArgs e)
        {
            if (Kite.Instruments_Download_Status)
            {
                MessageBox.Show("Instruments Downloaded");
            }
            else
            {
                MessageBox.Show("Instruments not Downloaded or in Progress");
            }
        }

        private void BtnSubscribe_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TxtExchange.Text))
            {
                MessageBox.Show("Please Enter Exch");
                return;
            }

            if (string.IsNullOrEmpty(TxtScript.Text))
            {
                MessageBox.Show("Please Enter TrdSymbol");
                return;
            }

            try
            {
                Kite.SubscribeQuotes(TxtExchange.Text, TxtScript.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUnsubscribe_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(TxtExchange.Text))
            {
                MessageBox.Show("Please Enter Exch");
                return;
            }

            if (string.IsNullOrEmpty(TxtScript.Text))
            {
                MessageBox.Show("Please Enter TrdSymbol");
                return;
            }

            try
            {
                Kite.UnSubscribeQuotes(TxtExchange.Text, TxtScript.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        public void Currentprice(string Scripname)
        {
            try
            {
                Kite.SubscribeQuotes("NSE", Scripname);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
