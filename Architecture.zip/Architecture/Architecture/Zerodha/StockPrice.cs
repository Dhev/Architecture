﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using KiteDotNet;
using Common;

namespace Zerodha
{
    public class StockPrice : IStockPrice
    {
        public event Error_EventHandler ErrorRised;
        public static Dictionary<string, double> stockDic = new Dictionary<string, double>();
        static Kite Kite;
        static bool eventAssigned;
        public StockPrice()
        {
            Kite = ZerodhaLogin.Kite;
            eventAssigned = false;
        }
        

        private void AddStock(string stock)
        {
            try
            {
                if (stockDic.ContainsKey(stock) == false)
                {
                    stockDic[stock] = 0;
                    if (eventAssigned == false)
                    {
                        Kite.QuotesReceivedEvent += Quotes_Received;
                        eventAssigned = true;
                    }
                    Kite.SubscribeQuotes("NSE", stock);
                }
            }
            catch (Exception ex)
            {
                ErrorRised(ex);
            }
        }

        public double GetPrice(string stock)
        {
            if (stockDic.ContainsKey(stock))
            {
                return stockDic[stock];
            }
            else
            {
                AddStock(stock);
                return 0;
            }
        }

        public void Quotes_Received(object sender, KiteDotNet.QuotesReceivedEventArgs e)
        {
            try
            {
                stockDic[e.TrdSym.ToUpper()] = e.Ltp;
                //MessageBox.Show(e.TrdSym + " " + e.Ltp + " " + e.Ltq);    
            }
            catch (Exception ex)
            {
                ErrorRised(ex);
            }
        }

        


        
     
    }
}
