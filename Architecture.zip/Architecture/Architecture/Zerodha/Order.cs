﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common;
using System.Data;
using KiteDotNet;
using System.Text.RegularExpressions;

namespace Zerodha
{
    public class Order : IOrder
    {
        public event Error_EventHandler ErrorRised;
        static Kite Kite;
 
        public Order()
        {
            Kite = ZerodhaLogin.Kite;
        }
 
        public string PlaceOrder(string stock, string ordertype, int qty, double price, double target, double stoploss)
        {
           
            try
            {
                qty=1;
                if (ordertype.ToUpper().Trim() == "BUY")
                {
                    target = target - price;
                    stoploss = price - stoploss;
                }
                else if(ordertype.ToUpper().Trim() == "SELL")
                {
                    target = price - target;
                    stoploss = stoploss - price;
                }

                qty = 1;
                String Orderid = Kite.PlaceBO("NSE", stock, ordertype, qty, price, target, stoploss, 0);
                return Orderid;
 
            }
 
            catch (Exception ex)
            {
                ErrorRised(ex);
            }
 
            return "";
            //  Kite.ExitCO(Orderid, Orderid);
        }

        public DataTable Getchildids()
        {
            DataTable dt = CreateTableFromOutputStream(Kite.GetOrderBook(), "dt");
            return dt;
        }
        //public void ModifyOrder() //(string parentid, int qty, double target, double stoploss)
        //{
 
        //    Kite.ModifyBOSl("NSE", "SINTEX", "170817000512261", "170817000507999", 34);
        //    //Kite.ModifyCOSl("NSE", stock, Orderid, Orderid, target);
 
 
        //    //  Kite.ExitCO(Orderid, Orderid);
        //    Kite.ExitBO("170817000512261", "170817000507999");
        //}
 
        private DataTable CreateTableFromOutputStream(string outputStreamText, string tableName)
        {
            //Process output and return
            string[] split = outputStreamText.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
 
            if (split.Length >= 2)
            {
                int iteration = 0;
                DataTable table = null;
 
                foreach (string values in split)
                {
                    if (iteration == 0)
                    {
                        string[] columnNames = SplitString(values);
                        table = new DataTable(tableName);
 
                        List<DataColumn> columnList = new List<DataColumn>();
 
                        foreach (string columnName in columnNames)
                        {
                            columnList.Add(new DataColumn(columnName));
                        }
 
                        table.Columns.AddRange(columnList.ToArray());
                    }
                    else
                    {
                        string[] fields = SplitString(values);
                        if (table == null)
                        {
                            table.Rows.Add(fields);
                        }
                    }
 
                    iteration++;
                }
 
                return table;
            }
 
            return null;
        }
 
        private string[] SplitString(string inputString)
        {
            System.Text.RegularExpressions.RegexOptions options = ((System.Text.RegularExpressions.RegexOptions.IgnorePatternWhitespace | System.Text.RegularExpressions.RegexOptions.Multiline)
                        | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            Regex reg = new Regex("(?:^|,)(\\\"(?:[^\\\"]+|\\\"\\\")*\\\"|[^,]*)", options);
            MatchCollection coll = reg.Matches(inputString);
            string[] items = new string[coll.Count];
            int i = 0;
            foreach (Match m in coll)
            {
                items[i++] = m.Groups[0].Value.Trim('"').Trim(',').Trim('"').Trim();
            }
            return items;
        }
 
        public void ExistOrder(string parentid)
        {
            DataTable dt = Getchildids();
            var query = from table in dt.AsEnumerable()
                        where table.Field<string>("Parent_Order_Id") == parentid
                        select table.Field<string>("Order_Id");
            foreach(var childid in query)
            {
                if (String.IsNullOrEmpty(childid))
                    Kite.ExitBO(parentid, childid);
            }
        }
 
 
        public void ModifyOrder(string parentid, int qty, double target, double stoploss)
        {
            DataTable dt = Getchildids();
            string stockname = GetStockname(dt,parentid, "LIMIT","OPEN");
            string orderid = GetOrderId(dt,parentid, "LIMIT", "OPEN");
            Kite.ModifyBOTgt("NSE", stockname, orderid, parentid, target);
 
            stockname = GetStockname(dt, parentid, "SL-M", "TRIGGER PENDING");
            orderid = GetOrderId(dt, parentid, "SL-M", "TRIGGER PENDING");
            Kite.ModifyBOSl("NSE", stockname, orderid, parentid, stoploss);
 
 
        }
 
        public string GetOrderId(DataTable dt,string parentid,string ordertype,string status)
        {
            var orderid = from myRow in dt.AsEnumerable()
                          where myRow.Field<string>("Parent_Order_Id") == parentid && myRow.Field<string>("Order_Type") == ordertype && myRow.Field<string>("Status") == status
                          select myRow.Field<string>("Order_Id").SingleOrDefault();
            return orderid.ToString();
        }
 
        public string GetStockname(DataTable dt,string parentid,string ordertype, string status)
        {
            var result = from myRow in dt.AsEnumerable()
                            where myRow.Field<string>("Parent_Order_Id") == parentid && myRow.Field<string>("Order_Type") == ordertype && myRow.Field<string>("Status") == status
                            select myRow.Field<string>("Trade_Symbol");
            var stockname = result.FirstOrDefault();
            return stockname.ToString();
        }
    }
}
